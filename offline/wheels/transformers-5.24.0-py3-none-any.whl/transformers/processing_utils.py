# Copyright 2022 The HuggingFace Inc. team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Processing saving/loading class for common processors.
"""

import bisect
import copy
import functools
import inspect
import json
import os
import re
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated, Any, Literal, TypedDict, TypeVar, Union, Unpack, is_typeddict

import numpy as np
from huggingface_hub import is_offline_mode
from huggingface_hub.dataclasses import validate_typed_dict
from huggingface_hub.errors import EntryNotFoundError

from .audio_utils import AudioInput, load_audio, make_list_of_audio
from .dynamic_module_utils import custom_object_save
from .feature_extraction_utils import BatchFeature
from .image_utils import (
    ChannelDimension,
    ImageInput,
    is_vision_available,
    make_flat_list_of_images,
)
from .tokenization_utils_base import (
    PaddingStrategy,
    PreTokenizedInput,
    PreTrainedTokenizerBase,
    TextInput,
    TruncationStrategy,
)
from .utils import (
    AUDIO_TOKENIZER_NAME,
    CHAT_TEMPLATE_DIR,
    CHAT_TEMPLATE_FILE,
    LEGACY_PROCESSOR_CHAT_TEMPLATE_FILE,
    PROCESSOR_NAME,
    PushToHubMixin,
    TensorType,
    auto_docstring,
    cached_file,
    copy_func,
    direct_transformers_import,
    hf_api,
    is_torch_available,
    is_torchcodec_greater_or_equal,
    is_torchcodec_usable,
    list_repo_templates,
    logging,
    resolve_revision,
)
from .utils.chat_template_utils import (
    _CONTROL_TOKEN_END,
    _CONTROL_TOKEN_START,
    _get_template_variables,
    _normalize_chat_messages,
    render_jinja_template,
)
from .utils.type_validators import (
    device_validator,
    image_size_validator,
    padding_validator,
    positive_any_number,
    positive_int,
    resampling_validator,
    tensor_type_validator,
    truncation_validator,
    video_metadata_validator,
)
from .video_utils import VideoInput, VideoMetadataType, make_batched_videos


if is_torch_available():
    import torch

    from .modeling_utils import PreTrainedAudioTokenizerBase

if is_vision_available():
    from .image_utils import PILImageResampling

logger = logging.get_logger(__name__)

# Matches where a mm placeholder isn't one that `mark_control_tokens` marked in user input
_UNMARKED = f"(?<!{_CONTROL_TOKEN_START})"
_MARKED_RE = re.compile(f"{_CONTROL_TOKEN_START}.*?{_CONTROL_TOKEN_END}")

# type hinting: specifying the type of processor class that inherits from ProcessorMixin
SpecificProcessorType = TypeVar("SpecificProcessorType", bound="ProcessorMixin")

# Dynamically import the Transformers module to grab the attribute classes of the processor from their names.
transformers_module = direct_transformers_import(Path(__file__).parent)


class _LazyAutoProcessorMapping(dict):
    """
    Lazy dictionary to avoid circular imports.
    The mapping names are only imported when accessed.
    """

    _MAPPING_NAMES = {
        "image_processor": ("transformers.models.auto.image_processing_auto", "AutoImageProcessor"),
        "video_processor": ("transformers.models.auto.video_processing_auto", "AutoVideoProcessor"),
        "feature_extractor": ("transformers.models.auto.feature_extraction_auto", "AutoFeatureExtractor"),
        "audio_processor": ("transformers.models.auto.feature_extraction_auto", "AutoFeatureExtractor"),
        "tokenizer": ("transformers.models.auto.tokenization_auto", "AutoTokenizer"),
    }

    def __getitem__(self, key):
        if key not in self._MAPPING_NAMES:
            raise KeyError(key)
        module_name, attr_name = self._MAPPING_NAMES[key]
        module = __import__(module_name, fromlist=[attr_name])
        return getattr(module, attr_name)

    def __contains__(self, key):
        return key in self._MAPPING_NAMES

    def keys(self):
        return self._MAPPING_NAMES.keys()


MODALITY_TO_AUTOPROCESSOR_MAPPING = _LazyAutoProcessorMapping()

MODALITY_TO_BASE_CLASS_MAPPING = {
    "audio_tokenizer": (
        "HiggsAudioV2TokenizerModel",
        "DacModel",
        "PocketTTSAudioTokenizerModel",
    ),  # TODO: @eustlb, to be replaced with PreTrainedAudioTokenizerBase
    "audio_processor": "FeatureExtractionMixin",
    "tokenizer": ("PreTrainedTokenizerBase", "MistralCommonBackend"),
    "feature_extractor": "FeatureExtractionMixin",
    "image_processor": "ImageProcessingMixin",
    "video_processor": "VideoProcessorMixin",
}

# The kwargs of a processor's `from_pretrained` that also apply to its audio tokenizer's `from_pretrained`
AUDIO_TOKENIZER_KWARGS = ("cache_dir", "force_download", "proxies", "token", "local_files_only", "device_map", "dtype")


def _get_modality_for_attribute(attribute_name: str) -> str:
    """
    Get the canonical modality type for a given attribute name.

    For example:
    - "image_processor" -> "image_processor"
    - "encoder_image_processor" -> "image_processor"
    - "text_tokenizer" -> "tokenizer"
    - "my_feature_extractor" -> "feature_extractor"
    """
    for modality in MODALITY_TO_AUTOPROCESSOR_MAPPING.keys():
        if modality in attribute_name:
            return modality
    raise ValueError(
        f"Cannot determine modality for attribute '{attribute_name}'. "
        f"Attribute name must contain one of: {list(MODALITY_TO_AUTOPROCESSOR_MAPPING.keys())}"
    )


class TextKwargs(TypedDict, total=False):
    """
    Keyword arguments for text processing. For extended documentation, check out tokenization_utils_base methods and
    docstrings associated.

    Attributes:
        add_special_tokens (`bool`, *optional*)
            Whether or not to add special tokens when encoding the sequences.
        padding (`bool`, `str` or [`~utils.PaddingStrategy`], *optional*)
            Activates and controls padding.
        truncation (`bool`, `str` or [`~tokenization_utils_base.TruncationStrategy`], *optional*):
            Activates and controls truncation.
        max_length (`int`, *optional*):
            Controls the maximum length to use by one of the truncation/padding parameters.
        stride (`int`, *optional*):
            If set, the overflowing tokens will contain some tokens from the end of the truncated sequence.
        is_split_into_words (`bool`, *optional*):
            Whether or not the input is already pre-tokenized.
        pad_to_multiple_of (`int`, *optional*):
            If set, will pad the sequence to a multiple of the provided value.
        return_token_type_ids (`bool`, *optional*):
            Whether to return token type IDs.
        return_attention_mask (`bool`, *optional*):
            Whether to return the attention mask.
        return_overflowing_tokens (`bool`, *optional*):
            Whether or not to return overflowing token sequences.
        return_special_tokens_mask (`bool`, *optional*):
            Whether or not to return special tokens mask information.
        return_offsets_mapping (`bool`, *optional*):
            Whether or not to return `(char_start, char_end)` for each token.
        return_length (`bool`, *optional*):
            Whether or not to return the lengths of the encoded inputs.
        verbose (`bool`, *optional*):
            Whether or not to print more information and warnings.
        padding_side (`str`, *optional*):
            The side on which padding will be applied.
        return_mm_token_type_ids (`bool`, *optional*):
            Deprecated, use [`ProcessingKwargs.return_mm_token_type_ids`] instead.
            Whether to return multimodal token type ids indicating mm placeholder token positions.
        return_text_replacement_offsets (`bool`, *optional*):
            Deprecated, use [`ProcessingKwargs.return_text_replacement_offsets`] instead.
            Whether to return character offsets for each mm placeholder and its replacement.
        sanitize_control_tokens (`bool`, *optional*):
            Whether the text was marked by `mark_control_tokens`: its marked control tokens are encoded as plain text,
            and aren't expanded as mm placeholders. Set by `apply_chat_template(..., sanitize_control_tokens=True)`.
        return_tensors (`str` or [`~utils.TensorType`], *optional*):
            If set, will return tensors of a particular framework. Acceptable values are:
            - `'pt'`: Return PyTorch `torch.Tensor` objects.
            - `'np'`: Return NumPy `np.ndarray` objects.
    """

    text_pair: TextInput | PreTokenizedInput | list[TextInput] | list[PreTokenizedInput] | None
    text_target: TextInput | PreTokenizedInput | list[TextInput] | list[PreTokenizedInput] | None
    text_pair_target: TextInput | PreTokenizedInput | list[TextInput] | list[PreTokenizedInput] | None
    add_special_tokens: bool | None
    padding: Annotated[bool | str | PaddingStrategy | None, padding_validator()]
    truncation: Annotated[bool | str | TruncationStrategy | None, truncation_validator()]
    max_length: Annotated[int | None, positive_int()]
    stride: Annotated[int | None, positive_int()]
    is_split_into_words: bool | None
    pad_to_multiple_of: Annotated[int | None, positive_int()]
    return_token_type_ids: bool | None
    return_attention_mask: bool | None
    return_overflowing_tokens: bool | None
    return_special_tokens_mask: bool | None
    return_offsets_mapping: bool | None
    return_length: bool | None
    verbose: bool | None
    padding_side: Literal["left", "right"] | None
    return_mm_token_type_ids: bool | None
    return_text_replacement_offsets: bool | None
    sanitize_control_tokens: bool | None
    return_tensors: Annotated[str | TensorType | None, tensor_type_validator()]


class ImagesKwargs(TypedDict, total=False):
    """
    Keyword arguments for image processing. For extended documentation, check the appropriate ImageProcessor
    class methods and docstrings.

    Attributes:
        do_convert_rgb (`bool`):
            Whether to convert the image to RGB format.
        do_resize (`bool`, *optional*):
            Whether to resize the image.
        size (`dict[str, int]`, *optional*):
            Resize using one of the supported size dictionaries. Pixel-area bounds use
            `{"min_pixels": int, "max_pixels": int}`.
        default_to_square (`bool`, *optional*, defaults to `self.default_to_square`):
            Whether to default to a square when resizing, if size is an int.
        crop_size (`dict[str, int]`, *optional*):
            Desired output size when applying center-cropping.
        resample (`PILImageResampling`, *optional*):
            Resampling filter to use if resizing the image.
        do_rescale (`bool`, *optional*):
            Whether to rescale the image by the specified scale `rescale_factor`.
        rescale_factor (`int` or `float`, *optional*):
            Scale factor to use if rescaling the image.
        do_normalize (`bool`, *optional*):
            Whether to normalize the image.
        image_mean (`float` or `list[float] or tuple[float, float, float]`, *optional*):
            Mean to use if normalizing the image.
        image_std (`float` or `list[float] or tuple[float, float, float]`, *optional*):
            Standard deviation to use if normalizing the image.
        do_pad (`bool`, *optional*):
            Whether to pad the images in the batch.
        pad_size (`dict[str, int]`, *optional*):
            The size `{"height": int, "width" int}` to pad the images to.
        do_center_crop (`bool`, *optional*):
            Whether to center crop the image.
        data_format (`ChannelDimension` or `str`, *optional*):
            The channel dimension format for the output image.
        input_data_format (`ChannelDimension` or `str`, *optional*):
            The channel dimension format for the input image.
        device (`Union[str, torch.Tensor]`, *optional*):
            The device to use for processing (e.g. "cpu", "cuda"), only relevant for torchvision backend.
        return_tensors (`str` or [`~utils.TensorType`], *optional*):
            If set, will return tensors of a particular framework. Acceptable values are:
            - `'pt'`: Return PyTorch `torch.Tensor` objects.
            - `'np'`: Return NumPy `np.ndarray` objects.
        disable_grouping (`bool`, *optional*):
            Whether to group images by shapes when processing or not, only relevant for torchvision backend.
        image_seq_length (`int`, *optional*):
            The number of image tokens to be used for each image in the input.
            Added for backward compatibility but this should be set as a processor attribute in future models.
    """

    do_convert_rgb: bool | None
    do_resize: bool | None
    size: Annotated[int | list[int] | tuple[int, ...] | dict[str, int] | None, image_size_validator()]
    default_to_square: bool | None
    crop_size: Annotated[int | list[int] | tuple[int, ...] | dict[str, int] | None, image_size_validator()]
    resample: Annotated[Union["PILImageResampling", int] | None, resampling_validator()]
    do_rescale: bool | None
    rescale_factor: float | None
    do_normalize: bool | None
    image_mean: float | list[float] | tuple[float, ...] | None
    image_std: float | list[float] | tuple[float, ...] | None
    do_pad: bool | None
    pad_size: Annotated[int | list[int] | tuple[int, ...] | dict[str, int] | None, image_size_validator()]
    do_center_crop: bool | None
    data_format: str | ChannelDimension | None
    input_data_format: str | ChannelDimension | None
    device: Annotated[Union[str, "torch.device"] | None, device_validator()]
    return_tensors: Annotated[str | TensorType | None, tensor_type_validator()]
    disable_grouping: bool | None
    image_seq_length: int | None


class VideosKwargs(TypedDict, total=False):
    """
    Keyword arguments for video processing.

    Attributes:
        do_convert_rgb (`bool`):
            Whether to convert the video to RGB format.
        do_resize (`bool`):
            Whether to resize the video.
        size (`dict[str, int]`, *optional*):
            Resize the shorter side of the input to `size["shortest_edge"]`.
        default_to_square (`bool`, *optional*, defaults to `self.default_to_square`):
            Whether to default to a square when resizing, if size is an int.
        resample (`PILImageResampling`, *optional*):
            Resampling filter to use if resizing the video.
        do_rescale (`bool`, *optional*):
            Whether to rescale the video by the specified scale `rescale_factor`.
        rescale_factor (`int` or `float`, *optional*):
            Scale factor to use if rescaling the video.
        do_normalize (`bool`, *optional*):
            Whether to normalize the video.
        image_mean (`float` or `list[float] or tuple[float, float, float]`, *optional*):
            Mean to use if normalizing the video.
        image_std (`float` or `list[float] or tuple[float, float, float]`, *optional*):
            Standard deviation to use if normalizing the video.
        do_center_crop (`bool`, *optional*):
            Whether to center crop the video.
        do_pad (`bool`, *optional*):
            Whether to pad the images in the batch.
        do_sample_frames (`bool`, *optional*):
            Whether to sample frames from the video before processing or to process the whole video.
        video_metadata (`Union[VideoMetadata, dict]`, *optional*):
            Metadata of the video containing information about total duration, fps and total number of frames.
        num_frames (`int`, *optional*):
            Maximum number of frames to sample when `do_sample_frames=True`.
        fps (`int` or `float`, *optional*):
            Target frames to sample per second when `do_sample_frames=True`.
        crop_size (`dict[str, int]`, *optional*):
            Desired output size when applying center-cropping.
        data_format (`ChannelDimension` or `str`, *optional*):
            The channel dimension format for the output video.
        input_data_format (`ChannelDimension` or `str`, *optional*):
            The channel dimension format for the input video.
        device (`Union[str, torch.Tensor]`, *optional*):
            The device to use for processing (e.g. "cpu", "cuda"), only relevant for fast image processing.
        return_metadata (`bool`, *optional*):
            Whether to return video metadata or not.
        return_tensors (`str` or [`~utils.TensorType`], *optional*):
            If set, will return tensors of a particular framework. Acceptable values are:
            - `'pt'`: Return PyTorch `torch.Tensor` objects.
            - `'np'`: Return NumPy `np.ndarray` objects.
    """

    do_convert_rgb: bool | None
    do_resize: bool | None
    size: Annotated[int | list[int] | tuple[int, ...] | dict[str, int] | None, image_size_validator()]
    default_to_square: bool | None
    resample: Annotated[Union["PILImageResampling", int] | None, resampling_validator()]
    do_rescale: bool | None
    rescale_factor: float | None
    do_normalize: bool | None
    image_mean: float | list[float] | tuple[float, ...] | None
    image_std: float | list[float] | tuple[float, ...] | None
    do_center_crop: bool | None
    do_pad: bool | None
    crop_size: Annotated[int | list[int] | tuple[int, ...] | dict[str, int] | None, image_size_validator()]
    data_format: str | ChannelDimension | None
    input_data_format: str | ChannelDimension | None
    device: Annotated[Union[str, "torch.device"] | None, device_validator()]
    do_sample_frames: bool | None
    video_metadata: Annotated[VideoMetadataType | None, video_metadata_validator()]
    fps: Annotated[int | float | None, positive_any_number()]
    num_frames: Annotated[int | None, positive_int()]
    return_metadata: bool | None
    return_tensors: Annotated[str | TensorType | None, tensor_type_validator()]


class AudioKwargs(TypedDict, total=False):
    """
    Keyword arguments for audio processing.

    Attributes:
        sampling_rate (`int`, *optional*):
            The sampling rate at which the `raw_speech` input was sampled.
        raw_speech (`np.ndarray`, `list[float]`, `list[np.ndarray]`, `list[list[float]]`):
            The sequence or batch of sequences to be padded. Each sequence can be a numpy array, a list of float
            values, a list of numpy arrays or a list of list of float values. Must be mono channel audio, not
            stereo, i.e. single float per timestep.
        padding (`bool`, `str` or [`~utils.PaddingStrategy`], *optional*):
            Select a strategy to pad the returned sequences (according to the model's padding side and padding
            index) among:

            - `True` or `'longest'`: Pad to the longest sequence in the batch (or no padding if only a single
                sequence if provided).
            - `'max_length'`: Pad to a maximum length specified with the argument `max_length` or to the maximum
                acceptable input length for the model if that argument is not provided.
            - `False` or `'do_not_pad'`
        max_length (`int`, *optional*):
            Maximum length of the returned list and optionally padding length (see above).
        truncation (`bool`, *optional*):
            Activates truncation to cut input sequences longer than *max_length* to *max_length*.
        pad_to_multiple_of (`int`, *optional*):
            If set, will pad the sequence to a multiple of the provided value.
        return_attention_mask (`bool`, *optional*):
            Whether or not [`~ASTFeatureExtractor.__call__`] should return `attention_mask`.
        device (`str` or `torch.device`, *optional*):
            The device to compute the audio features on (e.g. "cpu", "cuda"), only relevant for feature
            extractors that compute them with torch.
        return_tensors (`str` or [`~utils.TensorType`], *optional*):
            If set, will return tensors of a particular framework. Acceptable values are:
            - `'pt'`: Return PyTorch `torch.Tensor` objects.
            - `'np'`: Return NumPy `np.ndarray` objects.
        load_audio_backend (`str`, *optional*):
            Backend used by [`~audio_utils.load_audio`] to decode/resample audio referenced by URL/path
            in `apply_chat_template`. One of `"auto"`, `"torchcodec"`, `"soundfile"`, `"torchaudio"`
            (`"librosa"` is a deprecated alias of `"soundfile"`).
    """

    sampling_rate: Annotated[int | None, positive_int()]
    raw_speech: Union["np.ndarray", list[float], list["np.ndarray"], list[list[float]]] | None
    padding: Annotated[bool | str | PaddingStrategy | None, padding_validator()]
    max_length: Annotated[int | None, positive_int()]
    truncation: Annotated[bool | str | TruncationStrategy | None, truncation_validator()]
    pad_to_multiple_of: Annotated[int | None, positive_int()]
    return_attention_mask: bool | None
    device: Annotated[Union[str, "torch.device"] | None, device_validator()]
    return_tensors: Annotated[str | TensorType | None, tensor_type_validator()]
    load_audio_backend: str | None


class ProcessingKwargs(TypedDict, total=False):
    """Base class for kwargs passing to processors.

    In case a model has specific kwargs that are not present in the base class or default values for existing keys,
    it should have its own `ModelProcessorKwargs` class that inherits from `ProcessingKwargs` to provide additional
    typed keys that this model requires to process inputs.

    New keys have to be defined as follows to ensure type hinting is done correctly.

    ```python
    class ModelProcessorKwargs(ProcessingKwargs, total=False):
        my_kwarg: float

    class ModelProcessor(ProcessorMixin):
        valid_processor_kwargs = ModelProcessorKwargs

        @auto_docstring
        def __call__(self, images: ImageInput | None = None, ..., **kwargs: Unpack[ModelProcessorKwargs]):
            my_kwarg = kwargs.get("my_kwarg")
    ```
    """

    _defaults = {}  # Deprecated, kept for BC. Set defaults as class variables on the processor class inheriting from ProcessorMixin instead.

    text_kwargs: TextKwargs
    images_kwargs: ImagesKwargs
    videos_kwargs: VideosKwargs
    audio_kwargs: AudioKwargs

    return_mm_token_type_ids: bool
    return_text_replacement_offsets: bool


class OmniModalProcessingKwargs(ProcessingKwargs, total=False):
    load_audio_from_video: bool


class TokenizerChatTemplateKwargs(TypedDict, total=False):
    """
    NOTE: `TokenizerChatTemplateKwargs` is deprecated and will be removed in future versions
    Keyword arguments for tokenizer's `apply_chat_template`, when it is called from within a processor.

    tools (`list[Dict]`, *optional*):
        A list of tools (callable functions) that will be accessible to the model. If the template does not
        support function calling, this argument will have no effect. Each tool should be passed as a JSON Schema,
        giving the name, description and argument types for the tool. See our
        [chat templating guide](https://huggingface.co/docs/transformers/main/en/chat_templating#automated-function-conversion-for-tool-use)
        for more information.
    documents (`list[dict[str, str]]`, *optional*):
        A list of dicts representing documents that will be accessible to the model if it is performing RAG
        (retrieval-augmented generation). If the template does not support RAG, this argument will have no
        effect. We recommend that each document should be a dict containing "title" and "text" keys. Please
        see the RAG section of the [chat templating guide](https://huggingface.co/docs/transformers/main/en/chat_templating#arguments-for-RAG)
        for examples of passing documents with chat templates.
    add_generation_prompt (bool, *optional*):
        If this is set, a prompt with the token(s) that indicate
        the start of an assistant message will be appended to the formatted output. This is useful when you want to generate a response from the model.
        Note that this argument will be passed to the chat template, and so it must be supported in the
        template for this argument to have any effect.
    continue_final_message (bool or str, *optional*):
        If this is set, the chat will be formatted so that the final
        message in the chat is open-ended, without any EOS tokens. The model will continue this message
        rather than starting a new one. This allows you to "prefill" part of
        the model's response for it. If a string is passed, it will be used as the key for the field to continue
        (e.g. "reasoning_content"). Cannot be used at the same time as `add_generation_prompt`.

    return_assistant_tokens_mask (`bool`, defaults to `False`):
        Whether to return a mask of the assistant generated tokens. For tokens generated by the assistant,
        the mask will contain 1. For user and system tokens, the mask will contain 0.
        This functionality is only available for chat templates that support it via the `{% generation %}` keyword.
    reasoning_effort (`str`, *optional*):
        The reasoning effort level to use for the model's response. Supported values depend on the model
        (e.g. `"none"`, "low"`, `"medium"`, `"high"`). If the template does not support reasoning effort,
        this argument will have no effect.
    """

    tools: list[dict] | None = None
    documents: list[dict[str, str]] | None = None
    add_generation_prompt: bool | None = False
    continue_final_message: bool | str | None = False
    return_assistant_tokens_mask: bool | None = False
    reasoning_effort: str | None = None


class ProcessorChatTemplateKwargs(TokenizerChatTemplateKwargs, total=False):
    """
    NOTE: `ProcessorChatTemplateKwargs` is deprecated and will be removed in future versions

    Keyword arguments for processor's `apply_chat_template`.

    tokenize (`bool`, *optional*, defaults to `False`):
        Whether to tokenize the output or not.
    return_dict (`bool`, defaults to `False`):
        Whether to return a dictionary with named outputs. Has no effect if tokenize is `False`.
    load_audio_from_video (`bool`, *optional*, defaults to `False`):
        Whether to use the audio track of input video. If `True` the audio track will be loaded and passed to the
        processor. This flag has no effect if the model doesn't support audio modality.
    """

    tokenize: bool | None = False
    return_dict: bool | None = False
    load_audio_from_video: bool | None = False


class AllKwargsForChatTemplate(TypedDict, total=False):
    "NOTE: `AllKwargsForChatTemplate` is deprecated and will be removed in future versions"

    processor_kwargs: ProcessingKwargs
    template_kwargs: ProcessorChatTemplateKwargs


@dataclass
class MultiModalData:
    """
    Dataclass that holds extra useful data for processing
    multimodal data. Processors currently cannot return keys,
    unless it is used in model's forward. Thus we have helper
    methods that calculate and return useful data from processing
    input multimodals (images/videos).
    Note that this dataclass is aimed to be used only in vLLM
    and we might change its API in the future.
    """

    num_image_tokens: list[int] | None = None
    num_video_tokens: list[int] | None = None
    num_audio_tokens: list[int] | None = None
    num_image_patches: list[int] | None = None

    def __contains__(self, key):
        return hasattr(self, key) and getattr(self, key) is not None

    def __getitem__(self, key):
        if hasattr(self, key):
            return getattr(self, key)
        raise AttributeError(f"{self.__class__.__name__} has no attribute {key}")


@functools.lru_cache(maxsize=8)
def _merge_typed_dict(preprocessor_typed_dict: type, modality_typed_dict: type) -> type:
    return TypedDict(
        "merged_typed_dict",
        {**preprocessor_typed_dict.__annotations__, **modality_typed_dict.__annotations__},
        total=False,
    )


class ProcessorMixin(PushToHubMixin):
    """
    This is a mixin used to provide saving/loading functionality for all processor classes.
    """

    # Dynamically set sub-processor attributes. Not every processor has all of these;
    # they are populated via setattr in __init__ based on each subclass's `attributes`.
    tokenizer: Any
    feature_extractor: Any
    image_processor: Any
    video_processor: Any
    chat_template: str | dict[str, str] | None

    # Names need to be attr_class for attr in attributes
    _auto_class = None
    valid_processor_kwargs = ProcessingKwargs
    skip_tensor_conversion = ["video_metadata", "text_replacement_offsets"]

    # Default values for ProcessingKwargs.
    # Only override subprocessor kwargs if the subprocessor has a different default.
    # For example, to set `videos_kwargs = {"return_metadata": True}` to always request
    # metadata from the video processor.
    text_kwargs: TextKwargs
    images_kwargs: ImagesKwargs
    videos_kwargs: VideosKwargs
    audio_kwargs: AudioKwargs

    return_mm_token_type_ids = False
    return_text_replacement_offsets = False

    # args have to match the attributes class attribute
    def __init__(self, *args, **kwargs):
        # First, extract chat template from kwargs. It can never be a positional arg
        setattr(self, "chat_template", kwargs.pop("chat_template", None))

        # Check audio tokenizer for its class but do not treat it as attr to avoid saving weights
        if (audio_tokenizer := kwargs.pop("audio_tokenizer", None)) is not None:
            proper_class = self.check_argument_for_proper_class("audio_tokenizer", audio_tokenizer)
            if not (is_torch_available() and isinstance(audio_tokenizer, PreTrainedAudioTokenizerBase)):
                raise ValueError(
                    f"Tried to use `{proper_class}` for audio tokenization. However, this class is not"
                    " registered for audio tokenization."
                )
            setattr(self, "audio_tokenizer", audio_tokenizer)

        # Sanitize args and kwargs
        for key in kwargs:
            if key not in self.get_attributes():
                raise TypeError(f"Unexpected keyword argument {key}.")
        for arg, attribute_name in zip(args, self.get_attributes()):
            if attribute_name in kwargs:
                raise TypeError(f"Got multiple values for argument {attribute_name}.")
            else:
                kwargs[attribute_name] = arg

        if len(kwargs) != len(self.get_attributes()):
            raise ValueError(
                f"This processor requires {len(self.get_attributes())} arguments: {', '.join(self.get_attributes())}. Got "
                f"{len(args)} arguments instead."
            )

        # Check each arg is of the proper class (this will also catch a user initializing in the wrong order)
        for attribute_name, arg in kwargs.items():
            self.check_argument_for_proper_class(attribute_name, arg)
            setattr(self, attribute_name, arg)

    @auto_docstring
    def __call__(
        self,
        images: ImageInput | None = None,
        text: TextInput | PreTokenizedInput | list[TextInput] | list[PreTokenizedInput] | None = None,
        videos: VideoInput | None = None,
        audio: AudioInput | None = None,
        **kwargs: Unpack[ProcessingKwargs],
    ):
        images, text, videos, audio = self.prepare_inputs_layout(
            images=images, text=text, videos=videos, audio=audio, **kwargs
        )
        # Marked control tokens are user text: they don't count as mm placeholders
        unmarked_text = text
        if kwargs.get("sanitize_control_tokens") and text is not None:
            unmarked_text = [_MARKED_RE.sub("", sample) for sample in (text if isinstance(text, list) else [text])]
        self.validate_inputs(images=images, text=unmarked_text, videos=videos, audio=audio, **kwargs)

        merged_kwargs = self._merge_kwargs(
            tokenizer_init_kwargs=self.tokenizer.init_kwargs if hasattr(self, "tokenizer") else {},
            **kwargs,
        )

        processed_images = processed_videos = processed_audio = {}
        images_replacements = videos_replacements = audio_replacements = []
        if images is not None and hasattr(self, "image_processor"):
            processed_images, images_replacements = self._process_images(images, **merged_kwargs["images_kwargs"])
        if videos is not None and hasattr(self, "video_processor"):
            processed_videos, videos_replacements = self._process_videos(videos, **merged_kwargs["videos_kwargs"])
        if audio is not None and self._audio_processor is not None:
            processed_audio, audio_replacements = self._process_audio(audio, **merged_kwargs["audio_kwargs"])

        text_inputs = {}
        return_tensors = merged_kwargs["text_kwargs"].get("return_tensors", None)
        if getattr(self, "tokenizer", None) is not None and text is not None:
            # text_kwargs has priority for backwards compatibility. Remove in v5.29.0.
            return_mm_token_type_ids = merged_kwargs["text_kwargs"].pop(
                "return_mm_token_type_ids", merged_kwargs["return_mm_token_type_ids"]
            )
            return_text_replacement_offsets = merged_kwargs["text_kwargs"].pop(
                "return_text_replacement_offsets", merged_kwargs["return_text_replacement_offsets"]
            )

            text, text_replacement_offsets = self.get_text_with_replacements(
                text,
                images_replacements,
                videos_replacements,
                audio_replacements,
            )
            text_inputs = self.tokenizer(text, **merged_kwargs["text_kwargs"])
            self._check_special_mm_tokens(text, text_inputs, modalities=["image", "video", "audio"])

            if return_text_replacement_offsets:
                text_inputs["text_replacement_offsets"] = text_replacement_offsets

            if return_mm_token_type_ids:
                text_inputs["mm_token_type_ids"] = self.create_mm_token_type_ids(text_inputs["input_ids"])

        # Pop unused keys from the inputs, e.g. inputs used only to compute number of image tokens
        data = {**text_inputs, **processed_images, **processed_videos, **processed_audio}
        data = {k: v for k, v in data.items() if k not in self.unused_input_names}

        if not kwargs.get("return_metadata"):
            data.pop("video_metadata", None)

        return BatchFeature(data, tensor_type=return_tensors, skip_tensor_conversion=self.skip_tensor_conversion)

    def prepare_inputs_layout(
        self,
        images: ImageInput | None = None,
        text: TextInput | PreTokenizedInput | list[TextInput] | list[PreTokenizedInput] | None = None,
        videos: VideoInput | None = None,
        audio: AudioInput | None = None,
        **kwargs: Unpack[ProcessingKwargs],
    ):
        """
        Normalize and prefetch inputs before processing. Wraps text in a list for multimodal
        processors, fetches remote images and audio if URLs are provided, and ensures audio
        is properly batched. Returns the normalized `(images, text, videos, audio)` tuple.
        """
        # To support BC with models in pre-MLLM era, don't wrap text in list
        if self.all_special_multimodal_tokens and text is not None:
            if isinstance(text, str):
                text = [text]
            # avoid in-place updates on text
            text = list(text).copy()

        if audio is not None and self._audio_processor is not None:
            audio = self._audio_processor.fetch_audio(audio, sampling_rate=self._audio_processor.sampling_rate)
            audio = make_list_of_audio(audio)

        if images is not None and hasattr(self, "image_processor"):
            images = self.image_processor.fetch_images(images)

        return images, text, videos, audio

    def validate_inputs(
        self,
        images: ImageInput | None = None,
        text: TextInput | PreTokenizedInput | list[TextInput] | list[PreTokenizedInput] | None = None,
        videos: VideoInput | None = None,
        audio: AudioInput | None = None,
        **kwargs: Unpack[ProcessingKwargs],
    ):
        """
        Validate that at least one input is provided and that no deprecated keyword arguments
        are used. Raises ``ValueError`` otherwise.

        Override when the processor needs additional validation on the input args.
        """
        if "audios" in kwargs and audio is None:
            raise ValueError("You passed keyword argument `audios` which is deprecated. Please use `audio` instead.")

        if images is None and text is None and videos is None and audio is None:
            raise ValueError(f"You need to provide at least one input to call {self.__class__.__name__}")

        # Check that number of placeholders in text is same as number of mm-data for models
        # that have a special multimodal placeholder token defined
        if text is not None:
            if not (
                isinstance(text, str) or (isinstance(text, list) and all(isinstance(sample, str) for sample in text))
            ):
                raise ValueError("`text` must be a string or list of strings.")

            if getattr(self, "image_token", None) is not None:
                n_images_in_text = [sample.count(self.image_token) for sample in text]
                if images is not None:
                    images = make_flat_list_of_images(images)
                    if sum(n_images_in_text) != len(images):
                        raise ValueError(
                            f"The total number of {self.image_token} tokens in the prompts should be the same as the number of images passed."
                            f" Found total {sum(n_images_in_text)} {self.image_token} tokens and {len(images)} images."
                        )
                elif any(n_images_in_text):
                    raise ValueError(
                        f"Found {sum(n_images_in_text)} {self.image_token} tokens in the text but no images were passed."
                    )

            if getattr(self, "video_token", None) is not None:
                n_videos_in_text = [sample.count(self.video_token) for sample in text]
                if videos is not None:
                    videos = make_batched_videos(videos)
                    if sum(n_videos_in_text) != len(videos):
                        raise ValueError(
                            f"The total number of {self.video_token} tokens in the prompts should be the same as the number of videos passed."
                            f" Found total {sum(n_videos_in_text)} {self.video_token} tokens and {len(videos)} videos."
                        )
                elif any(n_videos_in_text):
                    raise ValueError(
                        f"Found {sum(n_videos_in_text)} {self.video_token} tokens in the text but no videos were passed."
                    )

            if getattr(self, "audio_token", None) is not None:
                # by this point audio is a flat list because `prepare_inputs` has applied `make_list`
                n_audio_in_text = [sample.count(self.audio_token) for sample in text]
                if audio is not None:
                    n_audio_passed = len(audio) if isinstance(audio, (list, tuple)) else 1
                    if sum(n_audio_in_text) != n_audio_passed:
                        raise ValueError(
                            f"The total number of {self.audio_token} tokens in the prompts should be the same as the number of audio inputs passed."
                            f" Found total {sum(n_audio_in_text)} {self.audio_token} tokens and {n_audio_passed} audio inputs."
                        )
                elif any(n_audio_in_text):
                    raise ValueError(
                        f"Found {sum(n_audio_in_text)} {self.audio_token} tokens in the text but no audio inputs were passed."
                    )

    # Simple preprocessing includes calling the `subprocessor` and optionally
    # building placeholder strings. Each processor can override and add their
    # own special pre/post processing on top, e.g. see `audioflamingo`
    def _process_images(self, images: ImageInput, **kwargs):
        processed_images = self.image_processor(images, **kwargs)

        image_replacements = []
        if getattr(self, "image_token", None) is not None:
            # Some processors use nested struct, we need to flatten back if needed
            images = make_flat_list_of_images(images)
            for idx in range(len(images)):
                replacement_text = self.replace_image_token(processed_images, image_idx=idx, **kwargs)
                image_replacements.append(replacement_text)
        return processed_images, image_replacements

    def _process_videos(self, videos: VideoInput, **kwargs):
        processed_videos = self.video_processor(videos, **kwargs)

        video_replacements = []
        if getattr(self, "video_token", None) is not None:
            videos = make_batched_videos(videos)
            for idx in range(len(videos)):
                replacement_text = self.replace_video_token(processed_videos, video_idx=idx, **kwargs)
                video_replacements.append(replacement_text)

        return processed_videos, video_replacements

    @property
    def _audio_processor(self):
        # TODO: To be replaced with `audio_processor`
        return getattr(self, "audio_processor", getattr(self, "feature_extractor", None))

    def _process_audio(self, audio: AudioInput, **kwargs):
        processed_audio = self._audio_processor(audio, **kwargs)

        audio_replacements = []
        if getattr(self, "audio_token", None) is not None:
            for idx in range(len(audio)):
                replacement_text = self.replace_audio_token(processed_audio, audio_idx=idx, **kwargs)
                audio_replacements.append(replacement_text)

        return processed_audio, audio_replacements

    # To be overridden by each model's processor if they need to add placeholder tokens
    def replace_image_token(self, image_inputs: dict, image_idx: int, **kwargs) -> str:
        raise NotImplementedError

    def replace_video_token(self, video_inputs: dict, video_idx: int, **kwargs) -> str:
        raise NotImplementedError

    def replace_audio_token(self, audio_inputs: dict, audio_idx: int, **kwargs) -> str:
        raise NotImplementedError

    def get_text_with_replacements(
        self,
        text: list[str],
        images_replacements: list[str] = [],
        videos_replacements: list[str] = [],
        audio_replacements: list[str] = [],
    ) -> tuple[list[str], list[dict[str, Any]]]:
        """
        Replace multimodal placeholder tokens in a batch of text strings with their
        expanded representations, and return the modified texts alongside offset metadata.

        This method is the core text-side preprocessing step for multimodal inputs. It
        scans each text in the batch for special tokens (image, video, audio) and replaces
        them in-order with the pre-computed replacement strings produced by
        `self.replace_image_token` / `self.replace_video_token` / `self.replace_audio_token`.
        Replacements are consumed from each modality's list sequentially, so the i-th
        occurrence of e.g. ``self.image_token`` is replaced by ``images_replacements[i]``.

        To add a new multimodal processor with placeholder tokens, you need to define a correct
        `self.image_token` which is the same token that is embedded in input text and also used as
        placeholder and repeated many times. Then you need to override `self.replace_image_token`
        to return the correct replacement string for a given image at index `i`. Same goes for all
        other supported modalities.

        Args:
            text (`list[str]`):
                Batch of raw text strings, each potentially containing multimodal
                placeholder tokens. Note that it will be modified in-place and returned.
            images_replacements (`list[str]`, *optional*, defaults to `[]`):
                Expanded replacement strings for each image, in the order they appear
                across the batch. Produced by `self._process_images`.
            videos_replacements (`list[str]`, *optional*, defaults to `[]`):
                Expanded replacement strings for each video. Produced by
                `self._process_videos`.
            audio_replacements (`list[str]`, *optional*, defaults to `[]`):
                Expanded replacement strings for each audio input. Produced by
                `self._process_audio`.

        Returns:
            `tuple[list[str], list[dict[str, Any]]]`: A tuple of:
                - The modified `text` batch with all placeholder tokens expanded.
                - `batch_replacement_offsets`: one entry per batch item, each being a
                list of dicts with keys:
                    - `"type"` (`str`): modality name — `"image"`, `"video"`, or `"audio"`
                    - `"span"` (`tuple[int, int]`): original `(start, end)` char offsets of the placeholder token
                    - `"new_span"` (`tuple[int, int]`): `(start, end)` offsets of placeholder in the expanded string
                    - `"text"` (`str`): the original placeholder token string that was matched
                    - `"replacement"` (`str`): the string it was replaced with
        """
        # Early exit if no special tokens found, nothing to replace or if text is not a list
        if not self.all_special_multimodal_tokens:
            return text, []

        # Use named regex so we can extract groups later and replace
        # TODO @raushan: vllm encodes text and mm-data separately causing errors when a placeholder
        # has no associated mm-data. Thus we can check if there are any `replacements` and skip otherwise
        # Plan: update all models and contrib to vllm, they might benefit largely from `replacement_offsets`
        token_groups = []
        if len(images_replacements) > 0 and (image_token := getattr(self, "image_token", None)) is not None:
            token_groups.append(f"(?P<image>{_UNMARKED}{re.escape(image_token)})")
        if len(videos_replacements) > 0 and (video_token := getattr(self, "video_token", None)) is not None:
            token_groups.append(f"(?P<video>{_UNMARKED}{re.escape(video_token)})")
        if len(audio_replacements) > 0 and (audio_token := getattr(self, "audio_token", None)) is not None:
            token_groups.append(f"(?P<audio>{_UNMARKED}{re.escape(audio_token)})")

        regex_special_mm_tokens = "|".join(token_groups) or r"(?!)"
        replacements_iters = {
            "image": iter(images_replacements),
            "video": iter(videos_replacements),
            "audio": iter(audio_replacements),
        }
        batch_replacement_offsets = []
        for batch_idx in range(len(text)):
            last = 0
            offset = 0
            replacement_offsets = []
            expanded_sample = []
            for m in re.finditer(regex_special_mm_tokens, text[batch_idx]):
                start, end = m.span()
                expanded_sample.append(text[batch_idx][last:start])

                # adjust spans using running offset if one sample has several MM data associated
                start_with_offset = start + offset

                mm_type = m.lastgroup
                replacement_text = next(replacements_iters[mm_type])
                replacement_offsets.append(
                    {
                        "type": mm_type,
                        "span": (start, end),
                        "new_span": (start_with_offset, start_with_offset + len(replacement_text)),
                        "text": m.group(),
                        "replacement": replacement_text,
                    }
                )
                expanded_sample.append(replacement_text)
                # update the offsets and the last position
                offset += len(replacement_text) - (end - start)
                last = end

            expanded_sample.append(text[batch_idx][last:])
            text[batch_idx] = "".join(expanded_sample)
            batch_replacement_offsets.append(replacement_offsets)
        return text, batch_replacement_offsets

    def create_mm_token_type_ids(self, input_ids: list) -> list[list[int]]:
        """
        Build per-token modality type IDs for a batch of token_id sequences.

        Each position is assigned an integer indicating which modality it belongs to:
        ``0`` for regular text, ``1`` for image tokens, ``2`` for video tokens, and
        ``3`` for audio tokens. Membership is determined by comparing against
        ``self.image_token_ids``, ``self.video_token_ids``, and ``self.audio_token_ids``.

        Args:
            input_ids (`list[list[int]]`):
                Batch of token ID sequences. May be unpadded (variable length), so
                a plain Python list of lists is expected rather than a tensor or
                uniformly-shaped array.

        Returns:
            `list[list[int]]`: A list of the same structure as ``input_ids``, where each
            integer is the modality type ID for the corresponding token.
        """
        mm_token_type_ids = []
        for tokenizer_input in input_ids:
            # Convert tensor rows to a list so `np.array` avoids NumPy 2.0's `__array__` copy-keyword deprecation.
            if not isinstance(tokenizer_input, list):
                tokenizer_input = tokenizer_input.tolist()
            tokenizer_input = np.array(tokenizer_input)
            mm_token_types = np.zeros_like(tokenizer_input)
            mm_token_types[np.isin(tokenizer_input, self.image_token_ids)] = 1
            mm_token_types[np.isin(tokenizer_input, self.video_token_ids)] = 2
            mm_token_types[np.isin(tokenizer_input, self.audio_token_ids)] = 3
            mm_token_type_ids.append(mm_token_types.tolist())
        return mm_token_type_ids

    @property
    def all_special_multimodal_tokens(self) -> list[str]:
        special_mm_tokens = [
            getattr(self, f"{modality}_token")
            for modality in ["image", "video", "audio"]
            if getattr(self, f"{modality}_token", None) is not None
        ]
        return special_mm_tokens

    # Special ids used per each modality in multimodal models. Models need to
    # override if they use special BOI/EOI/row/col/etc tokens that have to be marked
    # These values are used to build `mm_token_type_ids`
    @property
    def image_token_ids(self) -> list[int | None]:
        if _image_token_ids := getattr(self, "_image_token_ids", None):
            return _image_token_ids
        return [getattr(self, "image_token_id", None)]

    @image_token_ids.setter
    def image_token_ids(self, value: list[int | None]):
        setattr(self, "_image_token_ids", value)

    @property
    def video_token_ids(self) -> list[int | None]:
        if _video_token_ids := getattr(self, "_video_token_ids", None):
            return _video_token_ids
        return [getattr(self, "video_token_id", None)]

    @video_token_ids.setter
    def video_token_ids(self, value: list[int | None]):
        setattr(self, "_video_token_ids", value)

    @property
    def audio_token_ids(self) -> list[int | None]:
        if _audio_token_ids := getattr(self, "_audio_token_ids", None):
            return _audio_token_ids
        return [getattr(self, "audio_token_id", None)]

    @audio_token_ids.setter
    def audio_token_ids(self, value: list[int | None]):
        setattr(self, "_audio_token_ids", value)

    def check_argument_for_proper_class(self, argument_name, argument):
        """
        Checks the passed argument's class against the expected transformers class. In case of an unexpected
        mismatch between expected and actual class, an error is raise. Otherwise, the proper retrieved class
        is returned.
        """
        # If the exact attribute name is not in the mapping, use its canonical modality
        # (e.g., "encoder_tokenizer" -> "tokenizer")
        if argument_name not in MODALITY_TO_BASE_CLASS_MAPPING:
            argument_name = _get_modality_for_attribute(argument_name)
        class_name = MODALITY_TO_BASE_CLASS_MAPPING.get(argument_name)
        if isinstance(class_name, tuple):
            proper_class = tuple(self.get_possibly_dynamic_module(n) for n in class_name if n is not None)
        else:
            proper_class = self.get_possibly_dynamic_module(class_name)

        if not isinstance(argument, proper_class):
            raise TypeError(
                f"Received a {type(argument).__name__} for argument {argument_name}, but a {class_name} was expected."
            )

        return proper_class

    def to_dict(self) -> dict[str, Any]:
        """
        Serializes this instance to a Python dictionary.

        Returns:
            `dict[str, Any]`: Dictionary of all the attributes that make up this processor instance.
        """
        # Exclude tokenizer attributes before deepcopying to avoid copying large vocab/token structures.
        tokenizer_attributes = set()
        for attribute in self.__class__.get_attributes():
            if attribute in self.__dict__:
                modality = _get_modality_for_attribute(attribute)
                if modality == "tokenizer":
                    tokenizer_attributes.add(attribute)

        dict_to_copy = {k: v for k, v in self.__dict__.items() if k not in tokenizer_attributes}
        output = copy.deepcopy(dict_to_copy)

        # Get the kwargs in `__init__`.
        sig = inspect.signature(self.__init__)
        # Only save the attributes that are presented in the kwargs of `__init__`.
        # or in the attributes
        attrs_to_save = list(sig.parameters) + self.__class__.get_attributes()
        # extra attributes to be kept
        attrs_to_save += ["auto_map"]

        if "chat_template" in output:
            del output["chat_template"]

        def cast_array_to_list(dictionary):
            """
            Numpy arrays are not serialiazable but can be in pre-processing dicts.
            This function casts arrays to list, recusring through the nested configs as well.
            """
            for key, value in dictionary.items():
                if isinstance(value, np.ndarray):
                    dictionary[key] = value.tolist()
                elif isinstance(value, dict):
                    dictionary[key] = cast_array_to_list(value)
            return dictionary

        # Special case, add `audio_tokenizer` dict which points to model weights and path
        if "audio_tokenizer" in output:
            audio_tokenizer_dict = {
                "audio_tokenizer_class": self.audio_tokenizer.__class__.__name__,
                "audio_tokenizer_name_or_path": self.audio_tokenizer.name_or_path,
            }
            output["audio_tokenizer"] = audio_tokenizer_dict

        # Serialize attributes as a dict
        output = {
            k: v.to_dict() if isinstance(v, PushToHubMixin) else v
            for k, v in output.items()
            if (
                k in attrs_to_save  # keep all attributes that have to be serialized
                and v.__class__.__name__ != "BeamSearchDecoderCTC"  # remove attributes with that are objects
            )
        }
        output = cast_array_to_list(output)
        output["processor_class"] = self.__class__.__name__

        return output

    def to_json_string(self) -> str:
        """
        Serializes this instance to a JSON string.

        Returns:
            `str`: String containing all the attributes that make up this feature_extractor instance in JSON format.
        """
        dictionary = self.to_dict()

        return json.dumps(dictionary, indent=2, sort_keys=True) + "\n"

    def to_json_file(self, json_file_path: str | os.PathLike):
        """
        Save this instance to a JSON file.

        Args:
            json_file_path (`str` or `os.PathLike`):
                Path to the JSON file in which this processor instance's parameters will be saved.
        """
        with open(json_file_path, "w", encoding="utf-8") as writer:
            writer.write(self.to_json_string())

    def __repr__(self):
        attributes_repr = [f"- {name}: {repr(getattr(self, name))}" for name in self.get_attributes()]
        attributes_repr = "\n".join(attributes_repr)
        return f"{self.__class__.__name__}:\n{attributes_repr}\n\n{self.to_json_string()}"

    def save_pretrained(self, save_directory, push_to_hub: bool = False, **kwargs):
        """
        Saves the attributes of this processor (feature extractor, tokenizer...) in the specified directory so that it
        can be reloaded using the [`~ProcessorMixin.from_pretrained`] method.

        <Tip>

        This class method is simply calling [`~feature_extraction_utils.FeatureExtractionMixin.save_pretrained`] and
        [`~tokenization_utils_base.PreTrainedTokenizerBase.save_pretrained`]. Please refer to the docstrings of the
        methods above for more information.

        </Tip>

        Args:
            save_directory (`str` or `os.PathLike`):
                Directory where the feature extractor JSON file and the tokenizer files will be saved (directory will
                be created if it does not exist).
            push_to_hub (`bool`, *optional*, defaults to `False`):
                Whether or not to push your model to the Hugging Face model hub after saving it. You can specify the
                repository you want to push to with `repo_id` (will default to the name of `save_directory` in your
                namespace).
            kwargs (`dict[str, Any]`, *optional*):
                Additional key word arguments passed along to the [`~utils.PushToHubMixin.push_to_hub`] method.
        """
        os.makedirs(save_directory, exist_ok=True)

        if push_to_hub:
            commit_message = kwargs.pop("commit_message", None)
            repo_id = kwargs.pop("repo_id", save_directory.split(os.path.sep)[-1])
            repo_id = hf_api().create_repo(repo_id, exist_ok=True, **kwargs).repo_id
            files_timestamps = self._get_files_timestamps(save_directory)
        # If we have a custom config, we copy the file defining it in the folder and set the attributes so it can be
        # loaded from the Hub.
        if self._auto_class is not None:
            attrs = [getattr(self, attribute_name) for attribute_name in self.get_attributes()]
            configs = [(a.init_kwargs if isinstance(a, PreTrainedTokenizerBase) else a) for a in attrs]
            configs.append(self)
            custom_object_save(self, save_directory, config=configs)

        for attribute_name in self.get_attributes():
            attribute = getattr(self, attribute_name)

            modality = _get_modality_for_attribute(attribute_name)
            is_primary = attribute_name == modality
            if modality == "tokenizer":
                attribute._set_processor_class(self.__class__.__name__)
                # Save the tokenizer in its own vocab file. The other attributes are saved as part of `processor_config.json`
                if is_primary:
                    attribute.save_pretrained(save_directory)
                else:
                    # if a model has multiple tokenizers, save the additional tokenizers in their own folders.
                    attribute.save_pretrained(os.path.join(save_directory, attribute_name))
            elif attribute._auto_class is not None:
                custom_object_save(attribute, save_directory, config=attribute)

        if self._auto_class is not None:
            # We added an attribute to the init_kwargs of the tokenizers, which needs to be cleaned up.
            for attribute_name in self.get_attributes():
                attribute = getattr(self, attribute_name)
                if isinstance(attribute, PreTrainedTokenizerBase):
                    del attribute.init_kwargs["auto_map"]

        # If we save using the predefined names, we can load using `from_pretrained`
        # plus we save chat_template in its own file
        output_processor_file = os.path.join(save_directory, PROCESSOR_NAME)
        output_chat_template_file_jinja = os.path.join(save_directory, CHAT_TEMPLATE_FILE)
        chat_template_dir = os.path.join(save_directory, CHAT_TEMPLATE_DIR)

        # Save `chat_template` in its own file. We can't get it from `processor_dict` as we popped it in `to_dict`
        # to avoid serializing chat template in json config file. So let's get it from `self` directly
        if isinstance(self.chat_template, str):
            # New format for single templates is to save them as chat_template.jinja
            with open(output_chat_template_file_jinja, "w", encoding="utf-8") as f:
                f.write(self.chat_template)
            logger.info(f"chat template saved in {output_chat_template_file_jinja}")
        elif isinstance(self.chat_template, dict):
            # New format for multiple templates is to save the default as chat_template.jinja
            # and the other templates in the chat_templates/ directory
            for template_name, template in self.chat_template.items():
                if template_name == "default":
                    with open(output_chat_template_file_jinja, "w", encoding="utf-8") as f:
                        f.write(self.chat_template["default"])
                    logger.info(f"chat template saved in {output_chat_template_file_jinja}")
                else:
                    os.makedirs(chat_template_dir, exist_ok=True)
                    template_filepath = os.path.join(chat_template_dir, f"{template_name}.jinja")
                    # template_name is an untrusted dict key; reject path traversal (CWE-22)
                    if Path(template_filepath).resolve().parent != Path(chat_template_dir).resolve():
                        raise ValueError(f"Invalid chat template name: {template_name!r}")
                    with open(template_filepath, "w", encoding="utf-8") as f:
                        f.write(template)
                    logger.info(f"chat template saved in {template_filepath}")

        # Create a unified `preprocessor_config.json` and save all attributes as a composite config, except for tokenizers
        self.to_json_file(output_processor_file)
        logger.info(f"processor saved in {output_processor_file}")
        return_files = [output_processor_file]

        if push_to_hub:
            self._upload_modified_files(
                save_directory,
                repo_id,
                files_timestamps,
                commit_message=commit_message,
                token=kwargs.get("token"),
            )

        return return_files

    @classmethod
    def get_processor_dict(
        cls, pretrained_model_name_or_path: str | os.PathLike, **kwargs
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """
        From a `pretrained_model_name_or_path`, resolve to a dictionary of parameters, to be used for instantiating a
        processor of type [`~processing_utils.ProcessingMixin`] using `from_args_and_dict`.

        Parameters:
            pretrained_model_name_or_path (`str` or `os.PathLike`):
                The identifier of the pre-trained checkpoint from which we want the dictionary of parameters.
            subfolder (`str`, *optional*, defaults to `""`):
                In case the relevant files are located inside a subfolder of the model repo on huggingface.co, you can
                specify the folder name here.

        Returns:
            `tuple[Dict, Dict]`: The dictionary(ies) that will be used to instantiate the processor object.
        """
        # The audio tokenizer (if any) lives in another repository: it gets the Hub access and placement kwargs only, not
        # the ones that locate files in this repository (`revision`, `subfolder`) or override sub-processors.
        audio_tokenizer_kwargs = {key: kwargs[key] for key in AUDIO_TOKENIZER_KWARGS if key in kwargs}

        cache_dir = kwargs.pop("cache_dir", None)
        force_download = kwargs.pop("force_download", False)
        proxies = kwargs.pop("proxies", None)
        token = kwargs.pop("token", None)
        local_files_only = kwargs.pop("local_files_only", False)
        revision = kwargs.pop("revision", None)
        subfolder = kwargs.pop("subfolder", "")

        # Resolve the revision once, so that the template listing and all the files below come from the same repo state
        revision = resolve_revision(
            pretrained_model_name_or_path,
            revision,
            token=token,
            local_files_only=local_files_only,
            cache_dir=cache_dir,
        )

        from_pipeline = kwargs.pop("_from_pipeline", None)
        from_auto_class = kwargs.pop("_from_auto", False)

        user_agent = {"file_type": "processor", "from_auto_class": from_auto_class}
        if from_pipeline is not None:
            user_agent["using_pipeline"] = from_pipeline

        if is_offline_mode() and not local_files_only:
            logger.info("Offline mode: forcing local_files_only=True")
            local_files_only = True

        pretrained_model_name_or_path = str(pretrained_model_name_or_path)
        is_local = os.path.isdir(pretrained_model_name_or_path)
        if os.path.isdir(pretrained_model_name_or_path):
            processor_file = os.path.join(pretrained_model_name_or_path, PROCESSOR_NAME)

        additional_chat_template_files = {}
        resolved_additional_chat_template_files = {}
        if os.path.isfile(pretrained_model_name_or_path):
            resolved_processor_file = pretrained_model_name_or_path
            # can't load chat-template and audio tokenizer when given a file as pretrained_model_name_or_path
            resolved_chat_template_file = None
            resolved_raw_chat_template_file = None
            resolved_audio_tokenizer_file = None
            is_local = True
        else:
            if is_local:
                template_dir = Path(pretrained_model_name_or_path, CHAT_TEMPLATE_DIR)
                if template_dir.is_dir():
                    for template_file in template_dir.glob("*.jinja"):
                        template_name = template_file.stem
                        additional_chat_template_files[template_name] = f"{CHAT_TEMPLATE_DIR}/{template_file.name}"
            else:
                try:
                    for template in list_repo_templates(
                        pretrained_model_name_or_path,
                        local_files_only=local_files_only,
                        revision=revision,
                        cache_dir=cache_dir,
                        token=token,
                    ):
                        template = template.removesuffix(".jinja")
                        additional_chat_template_files[template] = f"{CHAT_TEMPLATE_DIR}/{template}.jinja"
                except EntryNotFoundError:
                    pass  # No template dir means no template files
            processor_file = PROCESSOR_NAME

            try:
                # Load from local folder or from cache or download from model Hub and cache
                resolved_processor_file = cached_file(
                    pretrained_model_name_or_path,
                    processor_file,
                    cache_dir=cache_dir,
                    force_download=force_download,
                    proxies=proxies,
                    local_files_only=local_files_only,
                    token=token,
                    user_agent=user_agent,
                    revision=revision,
                    subfolder=subfolder,
                    _raise_exceptions_for_missing_entries=False,
                )

                # chat_template.json is a legacy file used by the processor class
                # a raw chat_template.jinja is preferred in future
                resolved_chat_template_file = cached_file(
                    pretrained_model_name_or_path,
                    LEGACY_PROCESSOR_CHAT_TEMPLATE_FILE,
                    cache_dir=cache_dir,
                    force_download=force_download,
                    proxies=proxies,
                    local_files_only=local_files_only,
                    token=token,
                    user_agent=user_agent,
                    revision=revision,
                    subfolder=subfolder,
                    _raise_exceptions_for_missing_entries=False,
                )

                resolved_raw_chat_template_file = cached_file(
                    pretrained_model_name_or_path,
                    CHAT_TEMPLATE_FILE,
                    cache_dir=cache_dir,
                    force_download=force_download,
                    proxies=proxies,
                    local_files_only=local_files_only,
                    token=token,
                    user_agent=user_agent,
                    revision=revision,
                    subfolder=subfolder,
                    _raise_exceptions_for_missing_entries=False,
                )

                resolved_additional_chat_template_files = {
                    template_name: cached_file(
                        pretrained_model_name_or_path,
                        template_file,
                        cache_dir=cache_dir,
                        force_download=force_download,
                        proxies=proxies,
                        local_files_only=local_files_only,
                        token=token,
                        user_agent=user_agent,
                        revision=revision,
                        subfolder=subfolder,
                        _raise_exceptions_for_missing_entries=False,
                    )
                    for template_name, template_file in additional_chat_template_files.items()
                }

                resolved_audio_tokenizer_file = cached_file(
                    pretrained_model_name_or_path,
                    AUDIO_TOKENIZER_NAME,
                    cache_dir=cache_dir,
                    force_download=force_download,
                    proxies=proxies,
                    local_files_only=local_files_only,
                    token=token,
                    user_agent=user_agent,
                    revision=revision,
                    subfolder=subfolder,
                    _raise_exceptions_for_missing_entries=False,
                )
            except OSError:
                # Raise any environment error raise by `cached_file`. It will have a helpful error message adapted to
                # the original exception.
                raise
            except Exception:
                # For any other exception, we throw a generic error.
                raise OSError(
                    f"Can't load processor for '{pretrained_model_name_or_path}'. If you were trying to load"
                    " it from 'https://huggingface.co/models', make sure you don't have a local directory with the"
                    f" same name. Otherwise, make sure '{pretrained_model_name_or_path}' is the correct path to a"
                    f" directory containing a {PROCESSOR_NAME} file"
                )

        # Add chat template as kwarg before returning because most models don't have processor config
        if resolved_chat_template_file is not None:
            # This is the legacy path
            with open(resolved_chat_template_file, encoding="utf-8") as reader:
                chat_template_json = json.loads(reader.read())
                chat_templates = {"default": chat_template_json["chat_template"]}
                if resolved_additional_chat_template_files:
                    raise ValueError(
                        "Cannot load chat template due to conflicting files - this checkpoint combines "
                        "a legacy chat_template.json file with separate template files, which is not "
                        "supported. To resolve this error, replace the legacy chat_template.json file "
                        "with a modern chat_template.jinja file."
                    )
        else:
            chat_templates = {
                template_name: open(template_file, "r", encoding="utf-8").read()
                for template_name, template_file in resolved_additional_chat_template_files.items()
            }
            if resolved_raw_chat_template_file is not None:
                with open(resolved_raw_chat_template_file, "r", encoding="utf-8") as reader:
                    chat_templates["default"] = reader.read()
        if isinstance(chat_templates, dict) and "default" in chat_templates and len(chat_templates) == 1:
            chat_templates = chat_templates["default"]  # Flatten when we just have a single template/file

        # Existing processors on the Hub created before #27761 being merged don't have `processor_config.json` (if not
        # updated afterward), and we need to keep `from_pretrained` work. So here it fallbacks to the empty dict.
        # (`cached_file` called using `_raise_exceptions_for_missing_entries=False` to avoid exception)
        # However, for models added in the future, we won't get the expected error if this file is missing.
        if resolved_processor_file is None:
            # In any case we need to pass `chat_template` if it is available
            processor_dict = {}
        else:
            try:
                # Load processor dict
                with open(resolved_processor_file, encoding="utf-8") as reader:
                    text = reader.read()
                processor_dict = json.loads(text)

            except json.JSONDecodeError:
                raise OSError(
                    f"It looks like the config file at '{resolved_processor_file}' is not a valid JSON file."
                )

        if is_local:
            logger.info(f"loading configuration file {resolved_processor_file}")
        else:
            logger.info(f"loading configuration file {processor_file} from cache at {resolved_processor_file}")

        if processor_dict.get("chat_template") is not None:
            logger.warning_once(
                "Chat templates should be in a 'chat_template.jinja' file but found key='chat_template' "
                "in the processor's config. Make sure to move your template to its own file."
            )
        elif chat_templates:
            processor_dict["chat_template"] = chat_templates

        # Audio tokenizer needs to load the model checkpoint first, because the saved
        # json file contains only references to the model path and repo id
        if resolved_audio_tokenizer_file is not None or "audio_tokenizer" in processor_dict:
            if resolved_audio_tokenizer_file is not None:
                reader = open(resolved_audio_tokenizer_file, "r", encoding="utf-8")
                audio_tokenizer_dict = reader.read()
                audio_tokenizer_dict = json.loads(audio_tokenizer_dict)
            else:
                audio_tokenizer_dict = processor_dict["audio_tokenizer"]

            audio_tokenizer_class = cls.get_possibly_dynamic_module(audio_tokenizer_dict["audio_tokenizer_class"])
            audio_tokenizer_path = audio_tokenizer_dict["audio_tokenizer_name_or_path"]
            processor_dict["audio_tokenizer"] = audio_tokenizer_class.from_pretrained(
                audio_tokenizer_path, **audio_tokenizer_kwargs
            )

        return processor_dict, kwargs

    @classmethod
    def from_args_and_dict(cls, args, processor_dict: dict[str, Any], **kwargs):
        """
        Instantiates a type of [`~processing_utils.ProcessingMixin`] from a Python dictionary of parameters.

        Args:
            processor_dict (`dict[str, Any]`):
                Dictionary that will be used to instantiate the processor object. Such a dictionary can be
                retrieved from a pretrained checkpoint by leveraging the
                [`~processing_utils.ProcessingMixin.to_dict`] method.
            kwargs (`dict[str, Any]`):
                Additional parameters from which to initialize the processor object.

        Returns:
            [`~processing_utils.ProcessingMixin`]: The processor object instantiated from those
            parameters.
        """
        processor_dict = processor_dict.copy()
        return_unused_kwargs = kwargs.pop("return_unused_kwargs", False)

        # We have to pop up some unused (but specific) kwargs and then validate that it doesn't contain unused kwargs
        # If we don't pop, some specific kwargs will raise a warning or error
        for unused_kwarg in cls.get_attributes() + ["auto_map", "processor_class"]:
            processor_dict.pop(unused_kwarg, None)

        # override processor_dict with given kwargs
        processor_dict.update(kwargs)

        # check if there is an overlap between args and processor_dict
        accepted_args_and_kwargs = cls.__init__.__code__.co_varnames[: cls.__init__.__code__.co_argcount][1:]

        # validate both processor_dict and given kwargs
        unused_kwargs, valid_kwargs = cls.validate_init_kwargs(
            processor_config=processor_dict, valid_kwargs=accepted_args_and_kwargs
        )

        # update args that are already in processor_dict to avoid duplicate arguments
        args_to_update = {
            i: valid_kwargs.pop(arg)
            for i, arg in enumerate(accepted_args_and_kwargs)
            if (arg in valid_kwargs and i < len(args))
        }
        args = [args_to_update.get(i, arg) for i, arg in enumerate(args)]

        # instantiate processor with used (and valid) kwargs only
        processor = cls(*args, **valid_kwargs)

        logger.info(f"Processor {processor}")
        if return_unused_kwargs:
            return processor, unused_kwargs
        else:
            return processor

    def _merge_kwargs(
        self,
        ModelProcessorKwargs: ProcessingKwargs | None = None,
        tokenizer_init_kwargs: dict | None = None,
        **kwargs,
    ) -> dict[str, dict]:
        """
        Method to merge dictionaries of kwargs cleanly separated by modality within a Processor instance.

        The order of operations is as follows:
            1) Deprecated in favor of 2): kwargs passed as before have highest priority to preserve BC.
                ```python
                high_priority_kwargs = {"crop_size" = {"height": 222, "width": 222}, "padding" = "max_length"}
                processor(..., **high_priority_kwargs)
                ```
            2) Recommended: kwargs passed as modality-specific kwargs have second priority. This is the recommended API.
                ```python
                processor(..., text_kwargs={"padding": "max_length"}, images_kwargs={"crop_size": {"height": 222, "width": 222}}})
                ```
            3) Deprecated in favor of 2): "common_kwargs" passed as part of kwargs
                ```python
                kwargs = {"common_kwargs": {"return_tensors": "pt"}}
                processor(..., **kwargs)
                ```
            4) Deprecated in favor of 7): _defaults "common_kwargs" specified at processor level
                ```python
                class MyProcessingKwargs(ProcessingKwargs, total=False):
                    _defaults = {
                        # Common kwargs are passed to all modality-specific processors. They have priority over
                        # modality-specific defaults like "text_kwargs" or "images_kwargs".
                        "common_kwargs": {
                            "return_tensors": "pt",
                        },
                    }
                ```
            5) tokenizer attributes, followed by tokenizer init kwargs
                ```python
                tokenizer = tokenizer_class(..., {"padding": "max_length"})
                image_processor = image_processor_class(...)
                processor(tokenizer, image_processor) # will pass max_length to all modalities that support it unless overridden by kwargs at call
                ```
            6) Deprecated in favor of 7): defaults kwargs specified at processor level
                ```python
                class MyProcessingKwargs(ProcessingKwargs, total=False):
                    _defaults = {
                        "text_kwargs": {
                            "padding": "max_length",
                            "max_length": 64,
                        },
                    }
                ```
            7) Recommended: processor attributes have lowest priority. Defaults can be registered as class variables:
                ```python
                class MyProcessor(ProcessorMixin):
                    text_kwargs = {
                        "padding": "max_length",
                        "max_length": 64,
                    }
                ```
        Args:
            ModelProcessorKwargs (`ProcessingKwargs`):
                Typed dictionary of kwargs specifically required by the model passed.
            tokenizer_init_kwargs (`Dict`, *optional*):
                Dictionary of kwargs the tokenizer was instantiated with and need to take precedence over defaults.

        Returns:
            output_kwargs (`Dict`):
                ProcessingKwargs dictionary including per-modality kwargs to be passed to each modality-specific processor.

        """
        if ModelProcessorKwargs is None:
            ModelProcessorKwargs = self.valid_processor_kwargs

        # holding a copy to avoid mutating user-provided arguments
        # Use deepcopy to also copy nested dicts (like videos_kwargs) that will be modified via pop()
        kwargs = copy.deepcopy(kwargs)

        # Initialize dictionaries
        output_kwargs = {
            "text_kwargs": {},
            "images_kwargs": {},
            "audio_kwargs": {},
            "videos_kwargs": {},
        }

        map_preprocessor_kwargs = {
            "text_kwargs": "tokenizer",
            "images_kwargs": "image_processor",
            "audio_kwargs": "feature_extractor",
            "videos_kwargs": "video_processor",
        }

        possible_modality_keywords = {"text", "audio", "videos", "images"}

        modality_valid_kwargs = {}
        for modality in map_preprocessor_kwargs:
            # typed dict from e.g. ModelProcessorKwargs.images_kwargs
            valid_kwargs = set(ModelProcessorKwargs.__annotations__[modality].__annotations__)
            # typed dict from modality-specific processor.valid_kwargs
            # This is necessary because processor.valid_kwargs.images_kwargs == processor.image_processor.valid_kwargs
            # is not always the case as the image processor (or any other modality) can be from a different model.
            # E.g. when loading the image processor from a config.
            preprocessor = getattr(self, map_preprocessor_kwargs[modality], None)
            preprocessor_valid_kwargs = getattr(getattr(preprocessor, "valid_kwargs", None), "__annotations__", {})
            modality_valid_kwargs[modality] = set(valid_kwargs).union(preprocessor_valid_kwargs)

        valid_kwarg_to_modalities = defaultdict(list)
        for modality, valid_kwargs in modality_valid_kwargs.items():
            for key in valid_kwargs:
                valid_kwarg_to_modalities[key].append(modality)

        # 7): flat, not modality-specific processor attributes
        for key in ModelProcessorKwargs.__annotations__:
            if key not in map_preprocessor_kwargs and hasattr(self, key):
                output_kwargs[key] = copy.copy(getattr(self, key))

        processor_kwargs_defaults = getattr(ModelProcessorKwargs, "_defaults", {})
        for modality in map_preprocessor_kwargs:
            # 7): modality-specific processor attributes
            output_kwargs[modality].update(getattr(self, modality, {}).copy())

            # 6): _defaults overrides (BC)
            output_kwargs[modality].update(processor_kwargs_defaults.get(modality, {}).copy())

        # 5): update defaults with arguments from tokenizer init
        if tokenizer_init_kwargs is not None:
            for key in valid_kwarg_to_modalities:
                if key in tokenizer_init_kwargs:
                    # Yes, we update all modalities with tokenizer defaults. This is no bug.
                    for modality in valid_kwarg_to_modalities[key]:
                        output_kwargs[modality][key] = getattr(self.tokenizer, key, tokenizer_init_kwargs[key])

        # 4): `_defaults.common_kwargs` overrides (BC)
        common_kwargs = processor_kwargs_defaults.get("common_kwargs", {}).copy()
        # 3): common_kwargs passed by user (BC)
        common_kwargs.update(kwargs.pop("common_kwargs", {}))
        for modality in map_preprocessor_kwargs:
            output_kwargs[modality].update(common_kwargs)

        # BC: processor kwargs that used to be text kwargs. Remove in v5.29.0.
        mirrored_text_kwargs = ("return_mm_token_type_ids", "return_text_replacement_offsets")

        # kwargs passed by user
        for key, value in kwargs.items():
            if key in modality_valid_kwargs:
                # 2) key is modality-specific kwarg, e.g. "text_kwargs"
                modality = key
                for subkey, subvalue in value.items():
                    # BC: Remove in v5.29.0
                    if subkey in mirrored_text_kwargs and kwargs.get(subkey) == subvalue:
                        continue
                    if subkey in kwargs and subkey in modality_valid_kwargs[modality]:
                        raise ValueError(
                            f"Keyword argument {subkey} was passed two times:\n"
                            f"in a dictionary for {modality} and as a **kwarg."
                        )
                    output_kwargs[modality][subkey] = subvalue
            elif key in ModelProcessorKwargs.__annotations__:
                # 1) key is a processor kwarg, don't propagate to modality-specific kwargs
                output_kwargs[key] = value
            elif key in valid_kwarg_to_modalities:
                # 1) key is a valid kwarg for one or more modality-specific kwargs (BC)
                for modality in valid_kwarg_to_modalities[key]:
                    output_kwargs[modality][key] = value
            elif key not in possible_modality_keywords:
                logger.warning_once(
                    f"Keyword argument `{key}` is not a valid argument for this processor and will be ignored."
                )

        # BC: Copy legacy kwargs into text_kwargs. Remove in v5.29.0.
        for key in mirrored_text_kwargs:
            if key in kwargs.get("text_kwargs", {}) and key not in kwargs:
                logger.warning_once(
                    f"Passing `{key}` in `text_kwargs` is deprecated and will be removed in v5.29.0. "
                    "Pass it directly to the processor instead."
                )
            if key in kwargs:
                output_kwargs["text_kwargs"][key] = output_kwargs[key]
            elif key in output_kwargs["text_kwargs"]:
                output_kwargs[key] = output_kwargs["text_kwargs"][key]

        # Validate flat processor kwargs
        flat_kwargs = {
            key: value
            for key, value in output_kwargs.items()
            if not is_typeddict(ModelProcessorKwargs.__annotations__.get(key)) and key != "common_kwargs"
        }
        validate_typed_dict(ModelProcessorKwargs, flat_kwargs)

        # Validate modality-specific kwargs
        for modality, typed_dict_obj in ModelProcessorKwargs.__annotations__.items():
            if not is_typeddict(typed_dict_obj):
                continue
            elif modality in map_preprocessor_kwargs:
                # Same trick as for modality_valid_kwargs. Processor and preprocessor kwargs
                # are not necessarily the same.
                preprocessor = getattr(self, map_preprocessor_kwargs[modality], None)
                if preprocessor is None or getattr(preprocessor, "valid_kwargs", None) is None:
                    continue
                preprocessor_typed_dict_obj = getattr(preprocessor, "valid_kwargs")
                typed_dict_obj = _merge_typed_dict(preprocessor_typed_dict_obj, typed_dict_obj)

            validate_typed_dict(typed_dict_obj, output_kwargs[modality])

        return output_kwargs

    @classmethod
    def from_pretrained(
        cls: type[SpecificProcessorType],
        pretrained_model_name_or_path: str | os.PathLike,
        cache_dir: str | os.PathLike | None = None,
        force_download: bool = False,
        local_files_only: bool = False,
        token: str | bool | None = None,
        revision: str = "main",
        **kwargs,
    ) -> SpecificProcessorType:
        r"""
        Instantiate a processor associated with a pretrained model.

        <Tip>

        This class method is simply calling the feature extractor
        [`~feature_extraction_utils.FeatureExtractionMixin.from_pretrained`], image processor
        [`~image_processing_utils.ImageProcessingMixin`] and the tokenizer
        [`~tokenization_utils_base.PreTrainedTokenizer.from_pretrained`] methods. Please refer to the docstrings of the
        methods above for more information.

        </Tip>

        Args:
            pretrained_model_name_or_path (`str` or `os.PathLike`):
                This can be either:

                - a string, the *model id* of a pretrained feature_extractor hosted inside a model repo on
                  huggingface.co.
                - a path to a *directory* containing a feature extractor file saved using the
                  [`~SequenceFeatureExtractor.save_pretrained`] method, e.g., `./my_model_directory/`.
                - a path to a saved feature extractor JSON *file*, e.g.,
                  `./my_model_directory/preprocessor_config.json`.
            **kwargs
                Additional keyword arguments passed along to both
                [`~feature_extraction_utils.FeatureExtractionMixin.from_pretrained`] and
                [`~tokenization_utils_base.PreTrainedTokenizer.from_pretrained`].
        """
        kwargs["cache_dir"] = cache_dir
        kwargs["force_download"] = force_download
        kwargs["local_files_only"] = local_files_only
        # Resolve the revision once, so the processor config and all its sub-processors come from the same repo state.
        kwargs["revision"] = resolve_revision(
            pretrained_model_name_or_path,
            revision,
            token=token,
            local_files_only=local_files_only,
            cache_dir=cache_dir,
        )

        if token is not None:
            kwargs["token"] = token

        # Get processor_dict first so we can use it to instantiate non-tokenizer sub-processors
        processor_dict, instantiation_kwargs = cls.get_processor_dict(pretrained_model_name_or_path, **kwargs)
        args = cls._get_arguments_from_pretrained(pretrained_model_name_or_path, processor_dict, **kwargs)
        return cls.from_args_and_dict(args, processor_dict, **instantiation_kwargs)

    @classmethod
    def get_attributes(cls):
        args_in_init = inspect.signature(cls.__init__).parameters.keys()
        attributes = []
        for sub_processor_type in args_in_init:
            # don't treat audio_tokenizer as an attribute
            if sub_processor_type == "audio_tokenizer":
                continue
            if any(modality in sub_processor_type for modality in MODALITY_TO_AUTOPROCESSOR_MAPPING.keys()):
                attributes.append(sub_processor_type)

        # Legacy processors may not override `__init__` and instead expose modality
        # attributes via `<attribute>_class`. In that case, `args_in_init` only exposes
        # `*args`/`**kwargs`, so we need to infer the attributes from those class-level
        # hints to keep backward compatibility (e.g. dynamic processors stored on the Hub).
        if not attributes:
            for attribute_name, value in cls.__dict__.items():
                if value is None or attribute_name == "audio_tokenizer_class" or not attribute_name.endswith("_class"):
                    continue
                inferred_attribute = attribute_name[: -len("_class")]
                if inferred_attribute == "audio_tokenizer":
                    continue
                if any(modality in inferred_attribute for modality in MODALITY_TO_AUTOPROCESSOR_MAPPING.keys()):
                    attributes.append(inferred_attribute)

        return attributes

    @classmethod
    def register_for_auto_class(cls, auto_class="AutoProcessor"):
        """
        Register this class with a given auto class. This should only be used for custom feature extractors as the ones
        in the library are already mapped with `AutoProcessor`.



        Args:
            auto_class (`str` or `type`, *optional*, defaults to `"AutoProcessor"`):
                The auto class to register this new feature extractor with.
        """
        if not isinstance(auto_class, str):
            auto_class = auto_class.__name__

        import transformers.models.auto as auto_module

        if not hasattr(auto_module, auto_class):
            raise ValueError(f"{auto_class} is not a valid auto class.")

        cls._auto_class = auto_class

    @classmethod
    def _load_tokenizer_from_pretrained(
        cls, sub_processor_type, pretrained_model_name_or_path, subfolder="", **kwargs
    ):
        auto_processor_class = MODALITY_TO_AUTOPROCESSOR_MAPPING["tokenizer"]
        is_primary = sub_processor_type == "tokenizer"

        if is_primary:
            # Primary tokenizer: load from root
            tokenizer = auto_processor_class.from_pretrained(
                pretrained_model_name_or_path, subfolder=subfolder, **kwargs
            )
        else:
            # Additional tokenizer: load from subfolder (e.g., "decoder_tokenizer")
            tokenizer_subfolder = os.path.join(subfolder, sub_processor_type) if subfolder else sub_processor_type
            try:
                tokenizer = auto_processor_class.from_pretrained(
                    pretrained_model_name_or_path, subfolder=tokenizer_subfolder, **kwargs
                )
            except (OSError, ValueError):
                fallback_folder = "the root directory" if not subfolder else f"subfolder `{subfolder}`"
                logger.warning(
                    f"Could not load tokenizer from subfolder `{tokenizer_subfolder}`. "
                    f"Falling back to loading from {fallback_folder}. "
                    f"This behavior is deprecated and will be removed in a future version."
                )
                tokenizer = auto_processor_class.from_pretrained(
                    pretrained_model_name_or_path, subfolder=subfolder, **kwargs
                )
        return tokenizer

    @classmethod
    def _get_arguments_from_pretrained(cls, pretrained_model_name_or_path, processor_dict=None, **kwargs):
        """
        Identify and instantiate the subcomponents of Processor classes, such as image processors, tokenizers,
        and feature extractors. This method inspects the processor's `__init__` signature to identify parameters
        that correspond to known modality types (image_processor, tokenizer, feature_extractor, etc.) or contain
        modality names in their attribute name.

        For tokenizers: Uses the appropriate Auto class (AutoTokenizer) to load via `.from_pretrained()`.
        Additional tokenizers (e.g., "decoder_tokenizer") are loaded from subfolders.

        For other sub-processors (image_processor, feature_extractor, etc.): Primary ones are loaded via
        Auto class. Additional ones are instantiated from the config stored in processor_config.json
        (passed as processor_dict).

        Args:
            pretrained_model_name_or_path: Path or model id to load from.
            processor_dict: Optional dict containing processor config (from processor_config.json).
                Required when loading additional non-tokenizer sub-processors.
        """
        args = []
        processor_dict = processor_dict if processor_dict is not None else {}
        # Remove subfolder from kwargs to avoid duplicate keyword arguments
        subfolder = kwargs.pop("subfolder", "")

        # get args from processor init signature
        sub_processors = cls.get_attributes()
        for sub_processor_type in sub_processors:
            modality = _get_modality_for_attribute(sub_processor_type)
            is_primary = sub_processor_type == modality

            if (
                "tokenizer" in sub_processor_type
            ):  # This is only necessary for the checkpoint in test_processing_mistral3.py which has no config.json and
                # the tokenizer_config.json references LlamaTokenizerFast. TODO: update the config on the hub.
                if "PixtralProcessor" in cls.__name__:
                    from .tokenization_utils_tokenizers import TokenizersBackend

                    tokenizer = TokenizersBackend.from_pretrained(
                        pretrained_model_name_or_path, subfolder=subfolder, **kwargs
                    )
                else:
                    tokenizer = cls._load_tokenizer_from_pretrained(
                        sub_processor_type, pretrained_model_name_or_path, subfolder=subfolder, **kwargs
                    )
                args.append(tokenizer)
            elif is_primary:
                # Primary non-tokenizer sub-processor: load via Auto class
                auto_processor_class = MODALITY_TO_AUTOPROCESSOR_MAPPING[sub_processor_type]
                # For backward compatibility, check if sub-processor class name is hardcoded as an attribute of the processor class.
                if hasattr(cls, sub_processor_type + "_class"):
                    sub_processor_class_name = getattr(cls, sub_processor_type + "_class")
                    logger.warning_once(
                        f"`{cls.__name__}` defines `{sub_processor_type}_class = '{sub_processor_class_name}'`, "
                        f"which is deprecated. Register the correct mapping in `{auto_processor_class.__name__}` instead.",
                    )
                    auto_processor_class = cls.get_possibly_dynamic_module(sub_processor_class_name)
                sub_processor = auto_processor_class.from_pretrained(
                    pretrained_model_name_or_path, subfolder=subfolder, **kwargs
                )
                args.append(sub_processor)

            elif sub_processor_type in processor_dict:
                # Additional non-tokenizer sub-processor: instantiate from config in processor_dict
                sub_processor_config = processor_dict[sub_processor_type]
                if isinstance(sub_processor_config, dict):
                    # Determine the class to instantiate
                    # Image processors have 'image_processor_type', feature extractors have 'feature_extractor_type'
                    type_key = f"{modality}_type"
                    class_name = sub_processor_config.get(type_key)
                    if class_name is None:
                        raise ValueError(
                            f"Cannot instantiate {sub_processor_type}: missing '{type_key}' in config. "
                            f"Config keys: {list(sub_processor_config.keys())}"
                        )
                    processor_class = cls.get_possibly_dynamic_module(class_name)
                    sub_processor = processor_class(**sub_processor_config)
                    args.append(sub_processor)
                else:
                    raise ValueError(
                        f"Expected dict for {sub_processor_type} in processor_config.json, "
                        f"got {type(sub_processor_config)}"
                    )
            else:
                raise ValueError(
                    f"Cannot find config for {sub_processor_type} in processor_config.json. "
                    f"Available keys: {list(processor_dict.keys())}"
                )

        return args

    @staticmethod
    def get_possibly_dynamic_module(module_name):
        if hasattr(transformers_module, module_name):
            return getattr(transformers_module, module_name)
        lookup_locations = [
            transformers_module.IMAGE_PROCESSOR_MAPPING,
            transformers_module.VIDEO_PROCESSOR_MAPPING,
            transformers_module.TOKENIZER_MAPPING,
            transformers_module.FEATURE_EXTRACTOR_MAPPING,
            transformers_module.MODEL_FOR_AUDIO_TOKENIZATION_MAPPING,
        ]
        for lookup_location in lookup_locations:
            for custom_class in lookup_location._extra_content.values():
                if isinstance(custom_class, tuple):
                    for custom_subclass in custom_class:
                        if custom_subclass is not None and custom_subclass.__name__ == module_name:
                            return custom_subclass
                elif custom_class is not None and custom_class.__name__ == module_name:
                    return custom_class
        raise ValueError(
            f"Could not find module {module_name} in `transformers`. If this is a custom class, "
            f"it should be registered using the relevant `AutoClass.register()` function so that "
            f"other functions can find it!"
        )

    def batch_decode(self, *args, **kwargs):
        """
        This method forwards all its arguments to PreTrainedTokenizer's [`~PreTrainedTokenizer.batch_decode`]. Please
        refer to the docstring of this method for more information.
        """
        if not hasattr(self, "tokenizer"):
            raise ValueError(f"Cannot batch decode text: {self.__class__.__name__} has no tokenizer.")
        return self.tokenizer.batch_decode(*args, **kwargs)

    def decode(self, *args, **kwargs):
        """
        This method forwards all its arguments to PreTrainedTokenizer's [`~PreTrainedTokenizer.decode`]. Please refer to
        the docstring of this method for more information.
        """
        if not hasattr(self, "tokenizer"):
            raise ValueError(f"Cannot decode text: {self.__class__.__name__} has no tokenizer.")
        return self.tokenizer.decode(*args, **kwargs)

    @property
    def unused_input_names(self) -> list[str]:
        "Input names returned always by subprocessors but not used in model's `forward`"
        return []

    @property
    def model_input_names(self) -> list[str]:
        model_input_names = []
        for attribute_name in self.get_attributes():
            attribute = getattr(self, attribute_name, None)
            if attribute is not None:
                attr_input_names = getattr(attribute, "model_input_names")
                model_input_names.extend(attr_input_names)
        return [name for name in model_input_names if name not in self.unused_input_names]

    @staticmethod
    def validate_init_kwargs(processor_config, valid_kwargs):
        kwargs_from_config = set(processor_config.keys())
        valid_kwargs_set = set(valid_kwargs)

        unused_keys = kwargs_from_config - valid_kwargs_set
        valid_keys = kwargs_from_config & valid_kwargs_set

        unused_kwargs = {k: processor_config[k] for k in unused_keys} if unused_keys else {}
        valid_kwargs = {k: processor_config[k] for k in valid_keys} if valid_keys else {}

        return unused_kwargs, valid_kwargs

    def _multimodal_inputs_from_conversations(
        self,
        conversations: list[list[dict[str, str]]],
        audio_loading_params: dict,
        load_audio_from_video: bool = False,
    ):
        """
        Traverse through conversation and extract all provided multimodal data,
        including URL/path or already decoded inputs. Images and video are returned
        in nested format while audio is flattened into a single list for all batches.
        """
        batch_images, batch_videos, batch_audios = [], [], []
        for conversation in conversations:
            images, videos = [], []
            for message in conversation:
                content = message.get("content") or []
                if isinstance(content, str):
                    continue

                new_content = []  # don't modify user's dict in-place!

                # Single pass so that audio keeps the exact order of the conversation.
                # Audio models do not accept nested list of audios (yet!) so we construct a flat input audio list
                for block, next_block in zip(content, [*content[1:], None]):
                    new_content.append(block)
                    block_type = block["type"]
                    if block_type == "image":
                        images.extend(block[key] for key in ["image", "url", "path", "base64"] if key in block)
                    elif block_type == "video":
                        video_fnames = [block[key] for key in ["video", "url", "path"] if key in block]
                        videos.extend(video_fnames)
                        if load_audio_from_video:
                            batch_audios.extend(load_audio(fname, **audio_loading_params) for fname in video_fnames)
                            # One audio entry per video, right after it, so the template emits the `audio` token in the same spot.
                            # Deprecated since we dont want to dummy-insert, let users choose where to put audio!
                            if next_block != {"type": "audio"}:
                                new_content.append({"type": "audio"})
                                logger.warning_once(
                                    "When setting `load_audio_from_video=True` you must add an empty `audio` entry after each video in the conversation. "
                                    "From v5.25 the entry will NOT be added automatically when calling `processor.apply_chat_template()`"
                                )
                    elif block_type == "audio":
                        audio_fnames = [block[key] for key in ["audio", "url", "path"] if key in block]
                        batch_audios.extend(load_audio(fname, **audio_loading_params) for fname in audio_fnames)

                message["content"] = new_content

            # Currently all processors can accept nested list of batches, but not flat list of visuals
            # So we'll make a batched list of images and let the processor handle it
            batch_images.append(images)
            batch_videos.append(videos)
        return batch_images, batch_videos, batch_audios, {}

    def _resolve_chat_template(self, chat_template: str | None) -> str:
        """Return the template string to render, resolving defaults and template names."""
        if chat_template is None:
            if isinstance(self.chat_template, dict) and "default" in self.chat_template:
                return self.chat_template["default"]
            if isinstance(self.chat_template, dict):
                raise ValueError(
                    'The processor has multiple chat templates but none of them are named "default". You need to specify'
                    " which one to use by passing the `chat_template` argument. Available templates are: "
                    f"{', '.join(self.chat_template.keys())}"
                )
            if self.chat_template is not None:
                return self.chat_template
            raise ValueError("Cannot use apply_chat_template because this processor does not have a chat template.")

        if isinstance(self.chat_template, dict) and chat_template in self.chat_template:
            # It's the name of a template, not a full template string
            return self.chat_template[chat_template]
        # It's a template string, render it directly
        return chat_template

    def _prepare_processor_kwargs(
        self,
        chat_template: str,
        processor_kwargs: dict,
        kwargs: dict,
        add_generation_prompt: bool,
        continue_final_message: bool,
        return_assistant_tokens_mask: bool,
    ) -> dict:
        """Handle legacy **kwargs, validate flag combinations, and set offset-mapping options."""
        # Users might still be passing processing kwargs in `**kwargs` so we need to filter
        # out additional kwargs that the template expects via Jinja2 template introspection
        template_kwargs = _get_template_variables(chat_template)
        processor_kwargs_from_kwargs = {k: v for k, v in kwargs.items() if k not in template_kwargs}
        if processor_kwargs_from_kwargs:
            processor_kwargs = processor_kwargs.copy()
            logger.warning(
                "Kwargs passed to `processor.__call__` have to be in `processor_kwargs` dict, not in `**kwargs`"
            )
            processor_kwargs.update(processor_kwargs_from_kwargs)

        # Check if tokenizer is fast - use backend attribute if available, otherwise fall back to class name
        is_tokenizers_fast = False
        if hasattr(self, "tokenizer"):
            if hasattr(self.tokenizer, "backend"):
                is_tokenizers_fast = self.tokenizer.backend == "tokenizers"
            else:
                # Fallback to class name check
                is_tokenizers_fast = self.tokenizer.__class__.__name__.endswith("Fast")

        if continue_final_message:
            if add_generation_prompt:
                raise ValueError(
                    "continue_final_message and add_generation_prompt are not compatible. Use continue_final_message when you want the model to continue the final message, and add_generation_prompt when you want to add a header that will prompt it to start a new assistant message instead."
                )
            if return_assistant_tokens_mask:
                raise ValueError("continue_final_message is not compatible with return_assistant_tokens_mask.")

        if return_assistant_tokens_mask:
            if not is_tokenizers_fast:
                raise ValueError(
                    "`return_assistant_tokens_mask` is not possible with slow tokenizers. Make sure you have `tokenizers` installed. "
                    "If the error persists, open an issue to support a Fast tokenizer for your model."
                )
            # force offset mapping so we can infer token boundaries
            processor_kwargs["return_offsets_mapping"] = True
            processor_kwargs["return_text_replacement_offsets"] = True

        return processor_kwargs

    def _resolve_audio_loading_params(self, processor_kwargs: dict) -> dict:
        """Pick the sampling rate and backend used to load audio files."""
        audio_kwargs_from_user = processor_kwargs.get("audio_kwargs", {})

        sampling_rate = processor_kwargs.get("sampling_rate", audio_kwargs_from_user.get("sampling_rate"))
        if sampling_rate is None:
            if hasattr(self._audio_processor, "sampling_rate"):
                sampling_rate = self._audio_processor.sampling_rate
            else:
                sampling_rate = 16_000

        backend = processor_kwargs.get("load_audio_backend", audio_kwargs_from_user.get("load_audio_backend"))
        if backend is None:
            default_audio_kwargs = {
                **getattr(self, "audio_kwargs", {}),
                **getattr(self.valid_processor_kwargs, "_defaults", {}).get("audio_kwargs", {}),
            }
            backend = default_audio_kwargs.get("load_audio_backend", "auto")

        return {"sampling_rate": sampling_rate, "backend": backend}

    def _normalize_conversations(self, conversation) -> tuple[list, bool]:
        """Batch a single conversation if needed, drop the keys whose value is None, and convert OpenAI image_url
        blocks to HF image blocks."""
        if isinstance(conversation, (list, tuple)) and (
            isinstance(conversation[0], (list, tuple)) or hasattr(conversation[0], "messages")
        ):
            is_batched = True
            conversations = conversation
        else:
            is_batched = False
            conversations = [conversation]

        # Normalize: convert message objects to dicts and drop the keys whose value is None
        conversations = [_normalize_chat_messages(conversation) for conversation in conversations]

        # Normalize OpenAI-style "image_url" content blocks to HuggingFace-style "image" blocks
        # OpenAI format: {"type": "image_url", "image_url": {"url": "..."}}
        # HuggingFace format: {"type": "image", "url": "..."}
        for conversation in conversations:
            for message in conversation:
                if not isinstance(message.get("content"), list):
                    continue
                new_content = []
                for content in message["content"]:
                    if isinstance(content, dict) and content.get("type") == "image_url" and "image_url" in content:
                        image_url_info = content["image_url"]
                        url = image_url_info.get("url", "") if isinstance(image_url_info, dict) else image_url_info
                        new_content.append({"type": "image", "url": url})
                    else:
                        new_content.append(content)
                message["content"] = new_content

        return conversations, is_batched

    def _adjust_assistant_masks_indices(self, processed_dict: dict[str, Any], generation_indices: list[list[int]]):
        assistant_masks = []
        offset_mapping = processed_dict.pop("offset_mapping")
        input_ids = processed_dict["input_ids"]
        # We do some corrections here to ensure the assistant masks aren't
        # misaligned when we expand up image tokens
        replacement_offsets = processed_dict.pop("text_replacement_offsets", None)
        if replacement_offsets is None or len(replacement_offsets) == 0:
            replacement_offsets = [[]] * len(input_ids)
        for i in range(len(input_ids)):
            current_mask = [0] * len(input_ids[i])
            placeholder_ends = [r["span"][1] for r in replacement_offsets[i]]
            chars_gained = [0] + [r["new_span"][1] - r["span"][1] for r in replacement_offsets[i]]
            for span in generation_indices[i]:
                # Shift the span past any placeholders that were expanded before it
                start_char, end_char = (
                    char + chars_gained[bisect.bisect_right(placeholder_ends, char)] for char in span
                )
                # Mask every token overlapping the span. Zero-width tokens (padding, added specials) never
                # match, and a span truncated away simply matches nothing
                for pos, (token_start, token_end) in enumerate(offset_mapping[i]):
                    if token_start < end_char and token_end > start_char:
                        current_mask[pos] = 1
            assistant_masks.append(current_mask)
        processed_dict["assistant_masks"] = assistant_masks
        return processed_dict

    def apply_chat_template(
        self,
        conversation: list[dict[str, str]] | list[list[dict[str, str]]],
        chat_template: str | None = None,
        tools: list[dict] | None = None,
        documents: list[dict[str, str]] | None = None,
        add_generation_prompt: bool = False,
        continue_final_message: bool | str = False,
        return_assistant_tokens_mask: bool = False,
        tokenize: bool = False,
        return_tensors: str | TensorType | None = "auto",
        return_dict: bool = False,
        load_audio_from_video: bool = False,
        processor_kwargs: dict | None = None,
        sanitize_control_tokens: bool = False,
        **kwargs,
    ) -> str:
        """
        Similar to the `apply_chat_template` method on tokenizers, this method applies a Jinja template to input
        conversations to turn them into a single tokenizable string.

        The input is expected to be in the following format, where each message content is a list consisting of text and
        optionally image or video inputs. One can also provide an image, video, URL or local path which will be used to form
        `pixel_values` when `return_dict=True`. If not provided, one will get only the formatted text, optionally tokenized text.

        conversation = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "url": "https://www.ilankelman.org/stopsigns/australia.jpg"},
                    {"type": "text", "text": "Please describe this image in detail."},
                ],
            },
        ]

        Args:
            conversation (`Union[list[Dict, [str, str]], list[list[dict[str, str]]]]`):
                The conversation to format.
            chat_template (`Optional[str]`, *optional*):
                The Jinja template to use for formatting the conversation. If not provided, the tokenizer's
                chat template is used.
            sanitize_control_tokens (`bool`, defaults to `False`):
                Whether to encode the control tokens found in the conversation, tools, documents and the template
                variables passed as `**kwargs` as plain text, so that user input can't write them, nor mm placeholders.
                See the tokenizer's `apply_chat_template`.
                Requires `tokenize=True`.
        """
        processor_kwargs = processor_kwargs or {}

        chat_template = self._resolve_chat_template(chat_template)
        processor_kwargs = self._prepare_processor_kwargs(
            chat_template,
            processor_kwargs,
            kwargs,
            add_generation_prompt=add_generation_prompt,
            continue_final_message=continue_final_message,
            return_assistant_tokens_mask=return_assistant_tokens_mask,
        )
        audio_loading_params = self._resolve_audio_loading_params(processor_kwargs)
        conversations, is_batched = self._normalize_conversations(conversation)

        if tokenize:
            batch_images, batch_videos, batch_audios, additional_inputs = self._multimodal_inputs_from_conversations(
                conversations, audio_loading_params, load_audio_from_video
            )

        # `kwargs` overwrite special tokens if both are present
        if sanitize_control_tokens:
            conversations, tools, documents, kwargs = self.tokenizer._mark_chat_inputs(
                chat_template, conversations, tools, documents, kwargs, tokenize, return_assistant_tokens_mask
            )
            processor_kwargs["sanitize_control_tokens"] = True

        template_kwargs = {**self.tokenizer.special_tokens_map, **kwargs}
        prompt, generation_indices = render_jinja_template(
            conversations=conversations,
            tools=tools,
            documents=documents,
            chat_template=chat_template,
            return_assistant_tokens_mask=return_assistant_tokens_mask,
            continue_final_message=continue_final_message,
            add_generation_prompt=add_generation_prompt,
            **template_kwargs,
        )

        if not is_batched:
            prompt = prompt[0]

        if tokenize:
            # Tokenizer's `apply_chat_template` never adds special tokens. Processor's `apply_chat_template`
            # originally had no tokenize option, so users formatted the prompt themselves and passed it to the
            # processor, relying on it to handle everything internally (never worrying about special tokens).
            # This keeps BC for that flow and supports templates containing special tokens (consistent with
            # tokenizers). No warning is raised: it would flood the command line with nothing actionable for users.
            single_prompt = prompt[0] if is_batched else prompt
            if self.tokenizer.bos_token is not None and single_prompt.startswith(self.tokenizer.bos_token):
                processor_kwargs["add_special_tokens"] = False

            # Always sample frames by default unless explicitly set to `False` by users. If users do not pass
            # `num_frames`/`fps` sampling should not done for BC.
            if "do_sample_frames" not in processor_kwargs and (
                processor_kwargs.get("fps") is not None or processor_kwargs.get("num_frames") is not None
            ):
                processor_kwargs["do_sample_frames"] = True

            # We want to use each processor's own defaults by default when users don't pass anything
            # NOTE: in `elif` branch we need to use processor default for `assistant_masks` to be
            # same type as other keys but fine for now as it has been broken for a while
            if return_tensors != "auto":
                processor_kwargs["return_tensors"] = return_tensors
            else:
                return_tensors = None

            # Audio was loaded/resampled by us above, so let the audio processor know at which rate.
            # (we additionally preserve the location of the kwarg in the nested structure kwargs -> processor -> audio)
            if batch_audios:
                audio_kwargs_from_user = processor_kwargs.get("audio_kwargs", {})
                if "sampling_rate" in audio_kwargs_from_user:
                    processor_kwargs["audio_kwargs"] = {
                        **audio_kwargs_from_user,
                        "sampling_rate": audio_loading_params["sampling_rate"],
                    }
                else:
                    processor_kwargs["sampling_rate"] = audio_loading_params["sampling_rate"]

            # Images can also come in `processor_kwargs`, for templates that place them from other variables
            if images := processor_kwargs.pop("images", None):
                batch_images = [images] if not is_batched else images
            images_exist = any((im is not None) for im_list in batch_images for im in im_list)
            videos_exist = any((vid is not None) for vid_list in batch_videos for vid in vid_list)
            out = self(
                text=prompt,
                images=batch_images if images_exist else None,
                videos=batch_videos if videos_exist else None,
                audio=batch_audios or None,
                **additional_inputs,
                **processor_kwargs,
            )

            if return_dict:
                if return_assistant_tokens_mask:
                    out = self._adjust_assistant_masks_indices(out, generation_indices)
                    out.convert_to_tensors(tensor_type=return_tensors)
                return out
            else:
                return out["input_ids"]
        return prompt

    def parse_response(
        self,
        response: "str | list[int] | list[str] | list[list[int]] | np.ndarray | torch.Tensor",
        schema: dict | None = None,
        *,
        prefix: "str | list[int] | list[str] | list[list[int]] | np.ndarray | torch.Tensor | None" = None,
        tools: list[dict | Callable] | None = None,
    ):
        """
        Converts an output string created by generating text from a model into a parsed message dictionary.
        This method is intended for use with chat models, and will read the tokenizer's `response_template`
        attribute to control parsing, unless a `schema` argument is passed directly.

        Accepts either a single sequence (returning a single message `dict`) or a batch (returning a `list` of
        message dicts, one per item).

        Args:
            response (`str`, token ids, 1D/2D tensor, or a list of these):
                The output generated by the model, either decoded text or token ids, as a single sequence or a
                batch.
            schema (`dict`, *optional*):
                A response template. If not provided, the tokenizer's `response_template` attribute is used.
            prefix (`str`, token ids, 1D/2D tensor, or a list of these):
                The prompt that came before generation. Many chat templates pre-write part of the message, so
                this is needed to parse correctly. For a batched `response`, pass either a single prefix
                (broadcast to every item) or one prefix per item. Only supported with new-style templates.
            tools (`list[Union[Dict, Callable]]`, *optional*):
                Tools available to the model, in the same format as `apply_chat_template` accepts.
                Tool-call arguments are cast using the calling tool's JSON schema.
        """
        if not hasattr(self, "tokenizer"):
            raise ValueError("Can't use parse_response on a processor class without a tokenizer!")
        return self.tokenizer.parse_response(response, schema, prefix=prefix, tools=tools)

    def post_process_multimodal_output(
        self, generated_outputs, skip_special_tokens=True, generation_mode=None, **kwargs
    ):
        """
        Post-process the output of a multimodal model to return the requested modality output.
        If the model cannot generated the requested modality, an error will be raised.

        Args:
            generated_outputs (`torch.Tensor` or `np.ndarray`):
                The output of the model `generate` function. The output is expected to be a tensor of shape `(batch_size, sequence_length)`
                or `(sequence_length,)`.
            skip_special_tokens (`bool`, *optional*, defaults to `True`):
                Whether or not to remove special tokens in the output. Argument passed to the tokenizer's `batch_decode` method.
            generation_mode (`str`, *optional*):
                Generation mode indicated which modality to output and can be one of `["text", "image", "audio"]`.
            **kwargs:
                Additional arguments to be passed to the tokenizer's `batch_decode method`.

        Returns:
            `list[str]`: The decoded text.
        """
        if generation_mode is not None and generation_mode != "text":
            raise ValueError(
                f"{self.__class__.__name__} got an unexpected generation_mode={generation_mode}. Supported options are only [`text`]"
            )
        return self.post_process_image_text_to_text(
            generated_outputs, skip_special_tokens=skip_special_tokens, **kwargs
        )

    def post_process_image_text_to_text(self, generated_outputs, skip_special_tokens=True, **kwargs):
        """
        Post-process the output of a vlm to decode the text.

        Args:
            generated_outputs (`torch.Tensor` or `np.ndarray`):
                The output of the model `generate` function. The output is expected to be a tensor of shape `(batch_size, sequence_length)`
                or `(sequence_length,)`.
            skip_special_tokens (`bool`, *optional*, defaults to `True`):
                Whether or not to remove special tokens in the output. Argument passed to the tokenizer's `decode` method.
            **kwargs:
                Additional arguments to be passed to the tokenizer's `decode` method.

        Returns:
            `list[str]`: The decoded text.
        """
        return self.tokenizer.decode(generated_outputs, skip_special_tokens=skip_special_tokens, **kwargs)

    def _check_special_mm_tokens(self, text: list[str], text_inputs: "BatchFeature", modalities: list[str]):
        """
        Checks that number of special tokens in text and processed text is same. The count can be different
        if tokenized text was truncated, leading to issues in model code.
        """
        input_ids = text_inputs["input_ids"]
        if hasattr(input_ids, "tolist"):
            input_ids = input_ids.tolist()
        for modality in modalities:
            token_str = getattr(self, f"{modality}_token", None)
            token_id = getattr(self, f"{modality}_token_id", None)
            if token_str is not None and token_id is not None:
                ids_count = [list(ids).count(token_id) for ids in input_ids]
                text_count = [len(re.findall(_UNMARKED + re.escape(token_str), sample)) for sample in text]

                if ids_count != text_count:
                    raise ValueError(
                        f"Mismatch in `{modality}` token count between text and `input_ids`. Got ids={ids_count} and text={text_count}. "
                        "Likely due to `truncation='max_length'`. Please disable truncation or increase `max_length`."
                    )


class OmniModalProcessorMixin(ProcessorMixin):
    """
    This is a mixin used to provide additional functionality for omni-modal processor classes,
    including an API to load video and the corresponding audio track. New functions shared by omni
    models should be added here rather than in `ProcessorMixin` to keep simple processors apart from
    more involved models.
    Omni modal models are recommended to use this mixin from now on to get more functionality supported
    for cross-modal interactions.
    """

    valid_processor_kwargs = OmniModalProcessingKwargs

    load_audio_from_video = False

    @auto_docstring
    def __call__(
        self,
        images: ImageInput | None = None,
        text: TextInput | PreTokenizedInput | list[TextInput] | list[PreTokenizedInput] | None = None,
        videos: VideoInput | None = None,
        audio: AudioInput | None = None,
        audio_from_video_indices: list[int] | None = None,
        **kwargs: Unpack[OmniModalProcessingKwargs],
    ):
        r"""
        audio_from_video_indices (`list[int]`, *optional*):
            A list that describes the source of each audio slot where
                - `None` -> standalone audio associated with no video track
                - `i`    -> audio extracted from videos[i]
            If `audio` has one entry per slot, the audio of `videos[i]` is taken from it instead of decoded.
        """
        images, text, videos, audio = self.prepare_inputs_layout(
            images=images, text=text, videos=videos, audio=audio, **kwargs
        )
        merged_kwargs = self._merge_kwargs(
            tokenizer_init_kwargs=self.tokenizer.init_kwargs if hasattr(self, "tokenizer") else {},
            **kwargs,
        )

        if "load_audio_from_video" in merged_kwargs["videos_kwargs"]:
            logger.warning_once(
                "Passing `load_audio_from_video` in `videos_kwargs` is deprecated "
                "and will be removed in v5.29.0. "
                "Pass it directly to the processor instead."
            )
        # "videos_kwargs" has priority for backwards compatibility
        # Without videos there is no audio track to load, so `audio` is processed as usual
        load_audio_from_video = (
            merged_kwargs["videos_kwargs"].pop("load_audio_from_video", merged_kwargs["load_audio_from_video"])
            and videos is not None
        )
        merged_kwargs["load_audio_from_video"] = load_audio_from_video

        # Audio of a video has no placeholder in text, so only standalone slots are counted against it
        standalone_audio = audio
        if load_audio_from_video and audio and len(audio) == len(audio_from_video_indices or []):
            standalone_audio = [sample for sample, idx in zip(audio, audio_from_video_indices) if idx is None]
        self.validate_inputs(images=images, text=text, videos=videos, audio=standalone_audio, **kwargs)

        if load_audio_from_video:
            audio, video_to_audio_indices = self._resolve_audio_from_video(
                videos,
                audio=audio,
                audio_from_video_indices=audio_from_video_indices,
            )

        processed_images = processed_videos = processed_audio = {}
        images_replacements = videos_replacements = audio_replacements = []
        if images is not None and hasattr(self, "image_processor"):
            processed_images, images_replacements = self._process_images(images, **merged_kwargs["images_kwargs"])
        if audio is not None and self._audio_processor is not None:
            processed_audio, audio_replacements = self._process_audio(audio, **merged_kwargs["audio_kwargs"])
            if load_audio_from_video:
                audio_replacements = [
                    sample for idx, sample in enumerate(audio_replacements) if idx not in video_to_audio_indices
                ]
        if videos is not None and hasattr(self, "video_processor"):
            if load_audio_from_video:
                additional_kwargs = {
                    "audio": audio,
                    "processed_audio": processed_audio,
                    "video_to_audio_indices": video_to_audio_indices,
                }
                processed_videos, videos_replacements = self._process_videos(
                    videos, **additional_kwargs, **merged_kwargs
                )
            else:
                processed_videos, videos_replacements = self._process_videos(videos, **merged_kwargs)

        text_inputs = {}
        return_tensors = merged_kwargs["text_kwargs"].get("return_tensors", None)
        if getattr(self, "tokenizer", None) is not None and text is not None:
            # text_kwargs has priority for backwards compatibility. Remove in v5.29.0.
            return_mm_token_type_ids = merged_kwargs["text_kwargs"].pop(
                "return_mm_token_type_ids", merged_kwargs["return_mm_token_type_ids"]
            )
            return_text_replacement_offsets = merged_kwargs["text_kwargs"].pop(
                "return_text_replacement_offsets", merged_kwargs["return_text_replacement_offsets"]
            )

            text, text_replacement_offsets = self.get_text_with_replacements(
                text,
                images_replacements,
                videos_replacements,
                audio_replacements,
            )
            text_inputs = self.tokenizer(text, **merged_kwargs["text_kwargs"])
            self._check_special_mm_tokens(text, text_inputs, modalities=["image", "video", "audio"])

            if return_text_replacement_offsets:
                text_inputs["text_replacement_offsets"] = text_replacement_offsets

            if return_mm_token_type_ids:
                text_inputs["mm_token_type_ids"] = self.create_mm_token_type_ids(text_inputs["input_ids"])

        # Pop unused keys from the inputs, e.g. inputs used only to compute number of image tokens
        data = {**text_inputs, **processed_images, **processed_videos, **processed_audio}
        data = {k: v for k, v in data.items() if k not in self.unused_input_names}

        if not kwargs.get("return_metadata"):
            data.pop("video_metadata", None)

        return BatchFeature(data, tensor_type=return_tensors, skip_tensor_conversion=self.skip_tensor_conversion)

    def _resolve_audio_from_video(
        self,
        videos: list,
        audio: list | None = None,
        audio_from_video_indices: list[int | None] | None = None,
    ) -> tuple[list, list[int | None]]:
        """
        Resolve audio inputs and their relationship to input videos
        when `load_audio_from_video=True` and model requires native interleaving.

        `audio_from_video_indices` describes the source of each audio slot:
            - `None` -> standalone audio associated with no video track
            - `i`    -> audio extracted from videos[i]
        If `audio` has one entry per slot, the audio of `videos[i]` is taken from it instead of decoded.

        Returns:
            `audio (list[str | np.ndarray | torch.Tensor])`:
                Resolved audio inputs, with audio-from-video appended where needed.
                The order of audio will be aligned correctly with the input text, as
                long as users pass valid `audio_from_video_indices` in ambiguous situations
            `video_to_audio_indices (list[int, int])`:
                video_to_audio_indices[i] gives the audio index associated with
                videos[i], or None if the video has no associated audio.
        """
        audio = list(audio or [])
        videos = make_batched_videos(videos)

        if audio_from_video_indices is None:
            if audio:
                raise ValueError(
                    "Mixing `audio` with `load_audio_from_video=True` requires `audio_from_video_indices`."
                )
            audio_from_video_indices = list(range(len(videos)))  # videos only: one audio per video

        # Callers that already decoded the audio track of each video (e.g. vLLM) pass one audio per slot
        if len(audio) == len(audio_from_video_indices):
            video_to_audio = [None] * len(videos)
            for audio_idx, video_idx in enumerate(audio_from_video_indices):
                if video_idx is not None:
                    video_to_audio[video_idx] = audio_idx
            return audio if audio else None, video_to_audio

        if audio_from_video_indices.count(None) != len(audio):
            raise ValueError(
                f"`audio_from_video_indices` has {audio_from_video_indices.count(None)} standalone slots but {len(audio)} audio inputs."
            )

        if not (is_torchcodec_greater_or_equal("0.17") and is_torchcodec_usable(decode="audio")):
            raise ImportError(
                "`load_audio_from_video=True` requires torchcodec>=0.17 with FFmpeg. See "
                "https://github.com/meta-pytorch/torchcodec#installing-torchcodec."
            )
        from torchcodec.decoders import get_container_metadata

        standalone_audio = iter(audio)
        audio_resolved = []
        video_to_audio = [None] * len(videos)  # reverse mapping, `None` means no audio

        for video_idx in audio_from_video_indices:
            if video_idx is None:
                audio_resolved.append(next(standalone_audio))
                continue

            # Only `torchcodec` can decode audio track from all types of video file formats
            # Don't raise a load-error if video is silent and instead skip it
            cont_metadata = get_container_metadata(videos[video_idx])
            if not any(stream.media_type == "audio" for stream in cont_metadata.streams):
                continue

            loaded_audio = load_audio(
                videos[video_idx],
                backend="torchcodec",
                sampling_rate=self._audio_processor.sampling_rate,
            )
            video_to_audio[video_idx] = len(audio_resolved)
            audio_resolved.append(loaded_audio)

        # Empty list resolves to `None` since processors cannot handle empty inputs
        audio_resolved = audio_resolved if audio_resolved else None
        return audio_resolved, video_to_audio

    def _process_videos(
        self,
        videos: VideoInput,
        audio: AudioInput | None = None,
        processed_audio: dict | None = None,
        video_to_audio_indices: list | None = None,
        **kwargs: Unpack[OmniModalProcessingKwargs],
    ):
        processed_videos = self.video_processor(videos, **kwargs["videos_kwargs"])

        video_replacements = []
        videos = make_batched_videos(videos)
        for idx in range(len(videos)):
            replacement_text = self.replace_video_token(
                processed_videos,
                video_idx=idx,
                processed_audio=processed_audio,
                video_to_audio_indices=video_to_audio_indices,
                **kwargs,
            )
            video_replacements.append(replacement_text)
        return processed_videos, video_replacements

    def replace_video_token(
        self,
        video_inputs: dict,
        video_idx: int,
        audio: AudioInput | None = None,
        processed_audio: dict | None = None,
        video_to_audio_indices: list | None = None,
        **kwargs: Unpack[OmniModalProcessingKwargs],
    ) -> str:
        raise NotImplementedError()

    # Opt-in method, only models that support interleaving video-audio can override it
    # Not used by default and should be called explicitly by overriding `_process_video`
    # since models might have diff conditions to apply video+audio interleaved tokens
    def replace_video_with_audio_token(
        self,
        video_inputs: dict,
        video_idx: int,
        audio_inputs: dict,
        audio_idx: int,
        **kwargs: Unpack[OmniModalProcessingKwargs],
    ) -> str:
        raise NotImplementedError()

    def _multimodal_inputs_from_conversations(
        self,
        conversations: list[list[dict[str, str]]],
        audio_loading_params: dict,
        load_audio_from_video: bool = False,
    ):
        """
        Traverse through conversation and extract all provided multimodal data,
        including URL/path or already decoded inputs. Images and video are returned
        in nested format while audio is flattened into a single list for all batches.
        If `load_audio_from_video=True`, then each video is linked to audio within
        a batch via `audio_from_video_indices`
        """
        batch_images, batch_videos = [], []
        batch_audios, batch_audio_from_video_indices = [], []
        video_idx = 0
        for conversation in conversations:
            images, videos = [], []
            for message in conversation:
                content = message.get("content") or []
                if isinstance(content, str):
                    continue

                image_fnames = [
                    content_block[key]
                    for content_block in content
                    for key in ["image", "url", "path", "base64"]
                    if key in content_block and content_block["type"] == "image"
                ]
                images.extend(image_fnames)

                # Keep track of audio inputs and whether they comes from video or not
                for content_block in content:
                    if content_block["type"] == "video":
                        video = next(v for k in ("video", "url", "path") if (v := content_block.get(k)) is not None)
                        videos.append(video)
                        if load_audio_from_video:
                            batch_audio_from_video_indices.append(video_idx)

                        video_idx += 1
                    elif content_block["type"] == "audio":
                        audio = next(v for k in ("audio", "url", "path") if (v := content_block.get(k)) is not None)
                        batch_audios.append(load_audio(audio, **audio_loading_params))
                        batch_audio_from_video_indices.append(None)

            # Currently all processors can accept nested list of batches, but not flat list of visuals
            # So we'll make a batched list of images and let the processor handle it
            batch_images.append(images)
            batch_videos.append(videos)
        additional_inputs = {
            "audio_from_video_indices": batch_audio_from_video_indices,
            "load_audio_from_video": load_audio_from_video,
        }
        return batch_images, batch_videos, batch_audios, additional_inputs


ProcessorMixin.push_to_hub = copy_func(ProcessorMixin.push_to_hub)
if ProcessorMixin.push_to_hub.__doc__ is not None:
    ProcessorMixin.push_to_hub.__doc__ = ProcessorMixin.push_to_hub.__doc__.format(
        object="processor", object_class="AutoProcessor", object_files="processor files"
    )


def prepare_prompt_input(
    inputs: str | list[str] | None,
    batch_size: int,
    input_name: str = "inputs",
) -> list[str | None]:
    """
    Normalize a string, list of strings, or ``None`` into a list of length ``batch_size``.

    Args:
        inputs (`str`, `list[str]`, or `None`):
            The input to normalize. A single string is broadcast to all batch items; a list must
            match ``batch_size`` exactly; ``None`` produces a list of ``None`` values.
        batch_size (`int`):
            Expected length of the output list.
        input_name (`str`, *optional*, defaults to `"inputs"`):
            Name used in error messages to identify the argument.

    Returns:
        `list[str | None]`: A list of length ``batch_size``.
    """
    if inputs is None:
        return [None] * batch_size
    if isinstance(inputs, str):
        return [inputs] * batch_size
    if isinstance(inputs, (list, tuple)):
        if len(inputs) != batch_size:
            raise ValueError(
                f"Received {len(inputs)} {input_name} for {batch_size} audio sample(s); counts must match."
            )
        return list(inputs)
    raise TypeError(f"`{input_name}` must be a string, a sequence of strings, or `None`.")


def prepare_keyword_inputs(
    keywords: str | list[str] | list[list[str]] | None, batch_size: int
) -> list[list[str] | None]:
    """
    Broadcast and validate a hotword/keyword argument to match ``batch_size``.

    Args:
        keywords (`str`, `list[str]`, `list[list[str]]`, or `None`):
            The keyword(s) to bias transcription towards. A single string, or a flat list of strings, is broadcast
            to every sample in the batch. A list of lists must match ``batch_size``, one keyword list per sample.
            ``None`` disables keyword biasing for the whole batch.
        batch_size (`int`):
            The number of samples in the batch.

    Returns:
        `list[list[str] | None]`: A list of length ``batch_size``.
    """
    if isinstance(keywords, str):
        keywords = [keywords]
    if isinstance(keywords, (list, tuple)) and all(isinstance(item, str) for item in keywords):
        keywords = [list(keywords)] * batch_size

    return prepare_prompt_input(keywords, batch_size, input_name="keywords")
