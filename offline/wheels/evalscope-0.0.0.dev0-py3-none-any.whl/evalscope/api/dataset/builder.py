from pathlib import Path
from typing import TYPE_CHECKING, Callable, Dict, Iterable, List, Optional, Union

from .dataset import DatasetDict, FieldSpec, MemoryDataset, Sample, validate_dataset_repeats
from .hub import DatasetHub
from .loader import LocalDataLoader, _build_memory_dataset, _shuffle_in_place
from .utils import record_to_sample_fn

if TYPE_CHECKING:
    from evalscope.api.benchmark import DataAdapter


def build_dataset_from_records(
    records: Iterable[dict],
    sample_fields: Union[FieldSpec, Callable],
    *,
    name: str,
    location: Optional[str],
    limit: Optional[Union[int, float]],
    repeats: int,
    shuffle: bool,
    seed: Optional[int],
    filter_func: Optional[Callable[[Sample], bool]] = None,
    auto_id: bool = True,
) -> MemoryDataset:
    """Build a MemoryDataset from raw records using the standard adapter mechanics.

    Note:
        ``repeats`` duplicates each *resulting sample* (not the raw record) ``repeats``
        times consecutively, then ``reindex`` groups them with ``group_size=repeats``.
        This matches the single-sample-per-record adapters. If ``sample_fields`` maps one
        record to multiple samples, the per-sample duplication order differs from record
        level duplication, which callers relying on k-metric grouping should be aware of.
    """
    repeats = validate_dataset_repeats(repeats)
    record_list = list(records)
    if shuffle:
        _shuffle_in_place(record_list, seed)

    if limit is not None:
        if isinstance(limit, float):
            if not (0.0 <= limit <= 1.0):
                raise ValueError('Limit must be a non-negative integer or a float between 0 and 1.')
            limit = int(len(record_list) * limit)
        elif isinstance(limit, int) and limit < 0:
            raise ValueError('Limit must be a non-negative integer or a float between 0 and 1.')

    data_to_sample = record_to_sample_fn(sample_fields)
    return _build_memory_dataset(
        data=record_list,
        data_to_sample=data_to_sample,
        filter_func=filter_func,
        limit=limit,
        repeats=repeats,
        auto_id=auto_id,
        name=name,
        location=location,
        shuffled=shuffle,
    )


def build_dataset_dict_from_record_map(
    record_map: Dict[str, Iterable[dict]],
    sample_fields: Union[FieldSpec, Callable],
    *,
    location: Optional[str],
    limit: Optional[Union[int, float]],
    repeats: int,
    shuffle: bool,
    seed: Optional[int],
    filter_func: Optional[Callable[[Sample], bool]] = None,
    auto_id: bool = True,
) -> DatasetDict:
    """Build a DatasetDict from a mapping of subset name to raw records."""
    datasets = {}
    for subset, records in record_map.items():
        datasets[subset] = build_dataset_from_records(
            records=records,
            sample_fields=sample_fields,
            name=subset,
            location=location,
            limit=limit,
            repeats=repeats,
            shuffle=shuffle,
            seed=seed,
            filter_func=filter_func,
            auto_id=auto_id,
        )
    return DatasetDict(datasets)


def resolve_snapshot_or_local_path(
    adapter: 'DataAdapter',
    allow_file_pattern: Optional[Union[str, List[str]]] = None,
    *,
    allow_local_file: bool = False,
) -> str:
    """Resolve a snapshot root, accepting a direct local file only when explicitly enabled."""
    if allow_local_file:
        path = Path(adapter.dataset_id)
        if path.is_file():
            # Preserve symlink extensions and the filesystem meaning of ".." after directory symlinks.
            return str(path.absolute())
    return DatasetHub(
        data_id_or_path=adapter.dataset_id,
        data_source=adapter.dataset_hub,
        revision=adapter.dataset_revision,
        force_redownload=adapter.force_redownload,
        cache_dir=adapter.dataset_dir,
    ).download_snapshot(allow_file_pattern=allow_file_pattern)


def load_local_file_dataset(
    adapter: 'DataAdapter',
    dataset_path: str,
    subset: str,
    split: str,
    sample_fields: Union[FieldSpec, Callable],
    limit: Optional[Union[int, float]],
    repeats: int,
    shuffle: bool,
) -> MemoryDataset:
    """Load a local JSONL/CSV/TSV file or directory with the standard LocalDataLoader."""
    return LocalDataLoader(
        data_id_or_path=dataset_path,
        split=split,
        subset=subset,
        sample_fields=sample_fields,
        limit=limit,
        repeats=repeats,
        shuffle=shuffle,
        seed=adapter.seed,
    ).load()
