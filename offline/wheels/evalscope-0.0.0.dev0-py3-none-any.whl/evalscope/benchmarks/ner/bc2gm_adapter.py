from evalscope.api.benchmark import BenchmarkMeta, NERAdapter
from evalscope.api.registry import register_benchmark
from evalscope.constants import Tags
from evalscope.utils.ner import FEWSHOT_TEMPLATE, PROMPT_TEMPLATE

DESCRIPTION = """
## Overview

The BC2GM (BioCreative II Gene Mention) dataset is a widely used corpus for gene mention recognition, consisting of 20,000 sentences from MEDLINE abstracts where gene and protein names have been manually annotated by domain experts.

## Task Description

- **Task Type**: Biomedical Named Entity Recognition (NER)
- **Input**: Biomedical text from MEDLINE abstracts
- **Output**: Identified gene and protein name spans
- **Domain**: Molecular biology, genetics

## Key Features

- 20,000 sentences from MEDLINE abstracts
- Expert-annotated gene and protein mentions
- Benchmark from BioCreative II challenge
- Widely used for biomedical NER evaluation
- High-quality manual annotations

## Evaluation Notes

- Default configuration uses **5-shot** evaluation
- Metrics: Precision, Recall, F1-Score, Accuracy
- Entity types: GENE (gene and protein names)
"""  # noqa: E501


@register_benchmark(
    BenchmarkMeta(
        evaluation_version='v1.1',
        name='bc2gm',
        pretty_name='BC2GM',
        dataset_id='extraordinarylab/bc2gm',
        hf_dataset_id='extraordinarylab/bc2gm',
        tags=[Tags.KNOWLEDGE, Tags.NER],
        description=DESCRIPTION,
        few_shot_num=5,
        train_split='train',
        eval_split='test',
        metric_list=['precision', 'recall', 'f1_score', 'accuracy'],
        primary_metric='f1',
        prompt_template=PROMPT_TEMPLATE,
        few_shot_prompt_template=FEWSHOT_TEMPLATE,
    )
)
class BC2GMAdapter(NERAdapter):
    def __init__(self, **kwargs):
        # Initialize the parent class first
        super().__init__(**kwargs)

        # Define BC2GM-specific entity mappings
        self.entity_type_map = {'GENE': 'gene'}

        # Add descriptions for each entity type
        self.entity_descriptions = {'GENE': 'Names of genes and proteins'}

        # Setup entity mappings based on the defined entity types
        self.setup_entity_mappings()
