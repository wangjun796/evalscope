"""MT-Bench benchmark adapter."""
