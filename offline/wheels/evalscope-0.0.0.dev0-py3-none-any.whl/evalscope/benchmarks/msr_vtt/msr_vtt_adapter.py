import json
import os
from typing import Any, Dict, List, Optional, Tuple

from evalscope.api.benchmark import BenchmarkMeta, VisionLanguageAdapter
from evalscope.api.dataset import DatasetDict, DatasetHub, Sample, build_dataset_from_records
from evalscope.api.evaluator import TaskState
from evalscope.api.messages import ChatMessageUser, Content, ContentText, ContentVideo
from evalscope.api.metric import AggScore, SampleScore, Score
from evalscope.api.registry import register_benchmark
from evalscope.benchmarks.caption.metrics import (
    CAPTION_MAIN_SCORE,
    CAPTION_METRICS,
    aggregate_caption_scores,
    compute_caption_scores,
)
from evalscope.constants import HubType, Tags
from evalscope.utils.logger import get_logger
from evalscope.utils.media_utils import guess_video_format
from evalscope.utils.uri_utils import is_http_url

from .utils import DEFAULT_PROMPT, group_caption_records, optional_float

logger = get_logger()

MODELSCOPE_DATASET_ID = 'AI-ModelScope/msr-vtt'
HUGGINGFACE_DATASET_ID = 'VLM2Vec/MSR-VTT'


@register_benchmark(
    BenchmarkMeta(
        name='msr_vtt',
        pretty_name='MSR-VTT',
        description="""
## Overview

MSR-VTT is a large-scale open-domain video captioning benchmark for evaluating video-to-text generation.
The native adapter groups records by `video_id`, so multiple annotation rows for one video become one sample
with multiple reference captions.

## Task Description

- **Task Type**: Video captioning
- **Input**: Video clip or URL
- **Output**: One concise natural-language caption
- **Domains**: Open-domain video understanding and description

## Evaluation Notes

- Default data source: `AI-ModelScope/msr-vtt` on ModelScope, `validation` split
- Hugging Face `VLM2Vec/MSR-VTT` remains available by setting `dataset_hub="huggingface"` in TaskConfig
- Primary metric: **CIDEr**
- Additional metrics: BLEU-1/2/3/4, METEOR, ROUGE-L
- Set `extra_params.video_dir` to prefer local media files over URL metadata
""",
        tags=[Tags.MULTI_MODAL, Tags.VIDEO, Tags.IMAGE_CAPTIONING],
        dataset_id=MODELSCOPE_DATASET_ID,
        hf_dataset_id=HUGGINGFACE_DATASET_ID,
        paper_url='https://www.microsoft.com/en-us/research/publication/msr-vtt-a-large-video-description-dataset-for-bridging-video-and-language/',
        subset_list=['default'],
        metric_list=CAPTION_METRICS,
        primary_metric='cider',
        evaluation_version='v1.1',
        eval_split='validation',
        prompt_template=DEFAULT_PROMPT,
        extra_params={
            'video_dir': {
                'type': 'str',
                'description': 'Optional local directory containing MSR-VTT video files.',
                'value': '',
            },
            'video_extension': {
                'type': 'str',
                'description': 'Optional extension override for local videos, for example "mp4".',
                'value': '',
            },
        },
    )
)
class MSRVTTAdapter(VisionLanguageAdapter):
    """Adapter for MSR-VTT video captioning."""

    SOURCE_EVAL_SPLITS = {
        HubType.MODELSCOPE: 'validation',
        HubType.HUGGINGFACE: 'test',
    }

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.use_batch_scoring = True

    @property
    def uses_official_hf_dataset(self) -> bool:
        """Return whether the effective source is the built-in Hugging Face dataset."""
        return self.dataset_hub == HubType.HUGGINGFACE and self.dataset_id == HUGGINGFACE_DATASET_ID

    @property
    def source_eval_split(self) -> str:
        is_default_split = self.eval_split == self.SOURCE_EVAL_SPLITS[HubType.MODELSCOPE]
        if self.uses_official_hf_dataset and is_default_split:
            return self.SOURCE_EVAL_SPLITS[HubType.HUGGINGFACE]
        return self.eval_split

    @property
    def source_subset(self) -> str:
        return 'test_1k' if self.uses_official_hf_dataset else 'default'

    @property
    def source_dataset(self) -> DatasetHub:
        return DatasetHub(
            data_id_or_path=self.dataset_id,
            data_source=self.dataset_hub,
            revision=self.dataset_revision,
            force_redownload=self.force_redownload,
        )

    def load(self) -> Tuple[DatasetDict, None]:
        dataset_dict = {}
        for subset in self.subset_list:
            with self._temporary_attribute('current_subset_name', subset):
                records = group_caption_records(self._load_records())
                dataset = build_dataset_from_records(
                    records=records,
                    sample_fields=self.record_to_sample,
                    name=self.name,
                    location=self.dataset_id,
                    limit=self.limit,
                    repeats=self.repeats,
                    shuffle=self.shuffle,
                    seed=self.seed,
                )
                dataset_dict[subset] = dataset

        return DatasetDict(dataset_dict), None

    def record_to_sample(self, record: Dict[str, Any]) -> Sample:
        references = record.get('references', [])
        if not references:
            raise ValueError(f'No references found for MSR-VTT record: {record}')

        video = self._resolve_video(record)
        start = optional_float(record.get('start') or record.get('start time'), 'start')
        end = optional_float(record.get('end') or record.get('end time'), 'end')
        fps = optional_float(record.get('fps'), 'fps')

        content_list: List[Content] = [ContentText(text=self.prompt_template or DEFAULT_PROMPT)]
        if video:
            content_list.append(
                ContentVideo(video=video, format=guess_video_format(video), start=start, end=end, fps=fps)
            )

        return Sample(
            input=[ChatMessageUser(content=content_list)],
            target=json.dumps(references, ensure_ascii=False),
            metadata={
                'references': references,
                'subset': self.current_subset_name,
                'dataset_id': self.dataset_id,
                'dataset_hub': self.dataset_hub,
                'video': video,
                'start': start,
                'end': end,
                'fps': fps,
                'video_id': record.get('video_id'),
                'category': record.get('category'),
            },
        )

    def match_score(
        self, original_prediction: str, filtered_prediction: str, reference: str, task_state: TaskState
    ) -> Score:
        score = Score(extracted_prediction=filtered_prediction, prediction=original_prediction)
        score.value = {metric: 0.0 for metric in CAPTION_METRICS}
        score.main_score_name = CAPTION_MAIN_SCORE
        return score

    def batch_calculate_metrics(
        self, task_states: List[TaskState], sample_scores: List[SampleScore]
    ) -> List[SampleScore]:
        predictions = [self.filter_prediction(ts.output.completion, ts) for ts in task_states]
        references = [ts.metadata.get('references') or json.loads(ts.target) for ts in task_states]
        batch_scores = compute_caption_scores(predictions, references)
        for sample_score, values in zip(sample_scores, batch_scores):
            sample_score.score.value.update(values)
            sample_score.score.main_score_name = CAPTION_MAIN_SCORE
        return sample_scores

    def aggregate_scores(self, sample_scores: List[SampleScore]) -> List[AggScore]:
        return aggregate_caption_scores(sample_scores)

    def _load_records(self) -> List[Dict[str, Any]]:
        subset = self.source_subset
        logger.info(
            f'Loading MSR-VTT from {self.dataset_hub}: '
            f'{self.dataset_id}, subset={subset}, split={self.source_eval_split}.'
        )
        dataset = self.source_dataset.load(split=self.source_eval_split, subset=subset)
        return list(dataset)

    def _resolve_video(self, record: Dict[str, Any]) -> Optional[str]:
        video_name = record.get('video') or record.get('video_path')
        video_dir = self.extra_params.get('video_dir') or ''
        if video_dir and video_name:
            name = str(video_name)
            extension = self.extra_params.get('video_extension') or ''
            if extension:
                extension = extension if extension.startswith('.') else f'.{extension}'
                name = f'{os.path.splitext(name)[0]}{extension}'
            return os.path.join(os.path.abspath(video_dir), name)
        url = record.get('url')
        if url and is_http_url(str(url)):
            return str(url)
        return str(video_name) if video_name else None
